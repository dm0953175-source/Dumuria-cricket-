package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cricbuzz inspired color palette
val CricbuzzGreen = Color(0xFF1EAD61)      // Signature Sophisticated Green (#1EAD61)
val CricbuzzDarkGreen = Color(0xFF0D4D2D)  // Deeper shade (#0D4D2D)
val CricbuzzYellow = Color(0xFFFFD13B)     // Accent Yellow for milestones

// Dark Theme Colors
val DarkBackground = Color(0xFF000000)     // Pure Black (#000000)
val DarkSurface = Color(0xFF121212)        // Sophisticated Dark Surface (#121212)
val DarkCard = Color(0xFF121212)           // Sophisticated Card container background (#121212)
val DarkTextPrimary = Color(0xFFF1F5F9)    // Primary slate text (slate-100)
val DarkTextSecondary = Color(0xFF94A3B8)  // Muted slate gray text (slate-400)
val DarkBorder = Color(0xFF1F1F1F)         // Modern subtle dark border (#1F1F1F)

// Light Theme Colors
val LightBackground = Color(0xFFF4F6F9)    // Light grey-blue background
val LightSurface = Color(0xFFFFFFFF)       // Crisp white surface
val LightCard = Color(0xFFECEFF3)          // Light card container
val LightTextPrimary = Color(0xFF111827)   // Deep charcoal
val LightTextSecondary = Color(0xFF6B7280) // Grey text
val LightBorder = Color(0xFFE5E7EB)        // Light gray divider
