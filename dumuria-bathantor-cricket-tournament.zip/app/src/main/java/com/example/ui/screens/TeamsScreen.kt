package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entities.Player
import com.example.data.entities.Team
import com.example.ui.theme.CricbuzzGreen
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.viewmodel.CricketViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamsScreen(
    viewModel: CricketViewModel,
    modifier: Modifier = Modifier
) {
    val teams by viewModel.teams.collectAsState()
    var showAddTeamDialog by remember { mutableStateOf(false) }
    var newTeamName by remember { mutableStateOf("") }
    
    // Track which team card is expanded to show its players roster
    var expandedTeamId by remember { mutableStateOf<Int?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (teams.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Custom fallback layout alignment helper for older Compose versions
                Box(modifier = Modifier.weight(1f))
                    Icon(
                        imageVector = Icons.Default.Groups,
                        contentDescription = "No Teams",
                        tint = CricbuzzGreen.copy(alpha = 0.5f),
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No Teams Registered",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Create teams to organize the tournament, schedule fixtures, and start scoring matches.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = DarkTextSecondary,
                        modifier = Modifier.padding(horizontal = 24.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { showAddTeamDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("add_first_team_button")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add Team")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Add Your First Team", fontWeight = FontWeight.Bold)
                    }
                    Box(modifier = Modifier.weight(1f))
                }
            } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Registered Teams",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "${teams.size} teams participating",
                                style = MaterialTheme.typography.bodyMedium,
                                color = DarkTextSecondary
                            )
                        }
                        
                        FilledTonalButton(
                            onClick = { showAddTeamDialog = true },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = CricbuzzGreen.copy(alpha = 0.15f),
                                contentColor = CricbuzzGreen
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("add_team_btn")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Create Team", fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                items(teams) { team ->
                    val isExpanded = expandedTeamId == team.id
                    TeamCard(
                        team = team,
                        isExpanded = isExpanded,
                        onClick = {
                            expandedTeamId = if (isExpanded) null else team.id
                        },
                        viewModel = viewModel
                    )
                }
            }
        }

        if (showAddTeamDialog) {
            AlertDialog(
                onDismissRequest = { showAddTeamDialog = false },
                title = { Text("Create New Team", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("Enter the team name to register them in the tournament roster.", style = MaterialTheme.typography.bodyMedium, color = DarkTextSecondary)
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(
                            value = newTeamName,
                            onValueChange = { newTeamName = it },
                            label = { Text("Team Name") },
                            placeholder = { Text("e.g. Dumuria Kings") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CricbuzzGreen,
                                focusedLabelColor = CricbuzzGreen,
                                cursorColor = CricbuzzGreen
                            ),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("team_name_input")
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newTeamName.isNotBlank()) {
                                viewModel.addTeam(newTeamName.trim())
                                newTeamName = ""
                                showAddTeamDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("confirm_add_team")
                    ) {
                        Text("Create", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showAddTeamDialog = false },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.onBackground)
                    ) {
                        Text("Cancel")
                    }
                },
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

@Composable
fun TeamCard(
    team: Team,
    isExpanded: Boolean,
    onClick: () -> Unit,
    viewModel: CricketViewModel
) {
    val players by viewModel.getPlayersForTeam(team.id).collectAsState(initial = emptyList())
    var showAddPlayerRow by remember { mutableStateOf(false) }
    var newPlayerName by remember { mutableStateOf("") }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (isExpanded) CricbuzzGreen else DarkBorder, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .testTag("team_card_${team.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkCard)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CricbuzzGreen.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Groups,
                            contentDescription = "Team Icon",
                            tint = CricbuzzGreen,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = team.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${players.size} registered players",
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextSecondary
                        )
                    }
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "Collapse" else "Expand",
                    tint = DarkTextSecondary
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                ) {
                    Divider(color = DarkBorder, modifier = Modifier.padding(bottom = 12.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Squad Roster",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = CricbuzzGreen
                        )
                        
                        TextButton(
                            onClick = { showAddPlayerRow = !showAddPlayerRow },
                            colors = ButtonDefaults.textButtonColors(contentColor = CricbuzzGreen),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Icon(
                                imageVector = if (showAddPlayerRow) Icons.Default.Remove else Icons.Default.Add,
                                contentDescription = "Toggle add player",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (showAddPlayerRow) "Close" else "Add Player", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                    }

                    AnimatedVisibility(visible = showAddPlayerRow) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = newPlayerName,
                                onValueChange = { newPlayerName = it },
                                placeholder = { Text("Player Name", fontSize = 14.sp) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CricbuzzGreen,
                                    cursorColor = CricbuzzGreen
                                ),
                                singleLine = true,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                                    .testTag("player_name_input_${team.id}"),
                                textStyle = LocalTextStyle.current.copy(fontSize = 14.sp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (newPlayerName.isNotBlank()) {
                                        viewModel.addPlayer(team.id, newPlayerName.trim())
                                        newPlayerName = ""
                                        showAddPlayerRow = false
                                    }
                                },
                                modifier = Modifier
                                    .height(44.dp)
                                    .testTag("save_player_${team.id}"),
                                colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Add", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }

                    if (players.isEmpty()) {
                        Text(
                            text = "No players registered in this team yet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextSecondary,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            players.forEachIndexed { index, player ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(DarkBorder.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Player",
                                        tint = CricbuzzGreen.copy(alpha = 0.7f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = player.name,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.weight(1f))
                                    Text(
                                        text = "#${index + 1}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = DarkTextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
