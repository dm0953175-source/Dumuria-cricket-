package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entities.Match
import com.example.data.entities.Team
import com.example.ui.theme.CricbuzzGreen
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.viewmodel.CricketViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FixturesScreen(
    viewModel: CricketViewModel,
    onStartScoring: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val teams by viewModel.teams.collectAsState()
    val pointsTable by viewModel.pointsTable.collectAsState()
    val matches by viewModel.matches.collectAsState()

    var activeSubTab by remember { mutableStateOf("STANDINGS") } // STANDINGS or FIXTURES
    var showCreateMatchDialog by remember { mutableStateOf(false) }

    // State for creating a match
    var selectedTeamAId by remember { mutableStateOf<Int?>(null) }
    var selectedTeamBId by remember { mutableStateOf<Int?>(null) }
    var oversSelected by remember { mutableStateOf("5") }
    var matchDate by remember { mutableStateOf("") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Sub-Tabs Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkCard)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("STANDINGS" to "Points Table", "FIXTURES" to "Fixtures & Results").forEach { (tabId, tabName) ->
                    val isActive = activeSubTab == tabId
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isActive) CricbuzzGreen else Color.Transparent)
                            .clickable { activeSubTab = tabId }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tabName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isActive) Color.Black else Color.White
                        )
                    }
                }
            }

            if (activeSubTab == "STANDINGS") {
                // POINTS TABLE VIEW
                PointsTableLayout(pointsTable = pointsTable)
            } else {
                // FIXTURES LIST VIEW
                FixturesLayout(
                    matches = matches,
                    teams = teams,
                    onStartScoring = onStartScoring,
                    onCreateMatchClick = { showCreateMatchDialog = true }
                )
            }
        }

        // Add Match Dialog
        if (showCreateMatchDialog) {
            AlertDialog(
                onDismissRequest = { showCreateMatchDialog = false },
                title = { Text("Schedule Tournament Match", fontWeight = FontWeight.Bold) },
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Configure opposing teams, match overs length, and calendar date.", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                        
                        // Team A selection
                        Text("Select Team A (Home)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            teams.take(5).forEach { team ->
                                val isSelected = selectedTeamAId == team.id
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) CricbuzzGreen else DarkBorder)
                                        .border(1.dp, if (isSelected) CricbuzzGreen else Color.Transparent, RoundedCornerShape(6.dp))
                                        .clickable { selectedTeamAId = team.id }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(team.name.take(6), maxLines = 1, fontWeight = FontWeight.Bold, color = if (isSelected) Color.Black else Color.White, fontSize = 11.sp)
                                }
                            }
                        }

                        // Team B selection
                        Text("Select Team B (Away)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            teams.take(5).forEach { team ->
                                val isSelected = selectedTeamBId == team.id
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) CricbuzzGreen else DarkBorder)
                                        .border(1.dp, if (isSelected) CricbuzzGreen else Color.Transparent, RoundedCornerShape(6.dp))
                                        .clickable { selectedTeamBId = team.id }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(team.name.take(6), maxLines = 1, fontWeight = FontWeight.Bold, color = if (isSelected) Color.Black else Color.White, fontSize = 11.sp)
                                }
                            }
                        }

                        // Overs selection
                        Text("Match Length (Overs)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            listOf("5", "10", "15", "20").forEach { ov ->
                                val isSelected = oversSelected == ov
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) CricbuzzGreen else DarkBorder)
                                        .clickable { oversSelected = ov }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("${ov} Ov", fontWeight = FontWeight.Bold, color = if (isSelected) Color.Black else Color.White)
                                }
                            }
                        }

                        // Date field
                        OutlinedTextField(
                            value = matchDate,
                            onValueChange = { matchDate = it },
                            label = { Text("Match Date") },
                            placeholder = { Text("e.g. July 5, 2026") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CricbuzzGreen,
                                focusedLabelColor = CricbuzzGreen,
                                cursorColor = CricbuzzGreen
                            ),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("match_date_input")
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (selectedTeamAId != null && selectedTeamBId != null && selectedTeamAId != selectedTeamBId) {
                                val tA = teams.find { it.id == selectedTeamAId }
                                val tB = teams.find { it.id == selectedTeamBId }
                                if (tA != null && tB != null) {
                                    viewModel.createMatch(
                                        teamAId = tA.id,
                                        teamBId = tB.id,
                                        teamAName = tA.name,
                                        teamBName = tB.name,
                                        overs = oversSelected.toIntOrNull() ?: 5,
                                        date = if (matchDate.isBlank()) "Today" else matchDate.trim()
                                    )
                                    selectedTeamAId = null
                                    selectedTeamBId = null
                                    matchDate = ""
                                    showCreateMatchDialog = false
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("confirm_schedule_match")
                    ) {
                        Text("Schedule", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showCreateMatchDialog = false },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.onBackground)
                    ) {
                        Text("Cancel")
                    }
                },
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

@Composable
fun PointsTableLayout(pointsTable: List<Team>) {
    if (pointsTable.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.FormatListNumbered,
                    contentDescription = "No Points",
                    tint = CricbuzzGreen.copy(alpha = 0.5f),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text("Standings Empty", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color.White)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Standings and statistics will generate automatically once matches are played and scores are locked in.", color = DarkTextSecondary, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                // Table header row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkBorder, RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("#", modifier = Modifier.width(20.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary)
                    Text("TEAM", modifier = Modifier.weight(1.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                    Text("P", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White, textAlign = TextAlign.Center)
                    Text("W", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White, textAlign = TextAlign.Center)
                    Text("L", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White, textAlign = TextAlign.Center)
                    Text("PTS", modifier = Modifier.weight(0.4f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = CricbuzzGreen, textAlign = TextAlign.Center)
                    Text("NRR", modifier = Modifier.weight(0.5f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White, textAlign = TextAlign.End)
                }
            }

            items(pointsTable.size) { index ->
                val team = pointsTable[index]
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkCard, if (index == pointsTable.size - 1) RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp) else RoundedCornerShape(0.dp))
                        .padding(horizontal = 12.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("${index + 1}", modifier = Modifier.width(20.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = if (index < 2) CricbuzzGreen else DarkTextSecondary)
                    Text(team.name, modifier = Modifier.weight(1.3f), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White, maxLines = 1)
                    Text("${team.matchesPlayed}", modifier = Modifier.weight(0.3f), fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center)
                    Text("${team.wins}", modifier = Modifier.weight(0.3f), fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center)
                    Text("${team.losses}", modifier = Modifier.weight(0.3f), fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center)
                    Text("${team.points}", modifier = Modifier.weight(0.4f), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CricbuzzGreen, textAlign = TextAlign.Center)
                    
                    val formattedNrr = String.format(Locale.US, "%+1.3f", team.netRunRate)
                    Text(formattedNrr, modifier = Modifier.weight(0.5f), fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = if (team.netRunRate >= 0.0) CricbuzzGreen else Color.Red, textAlign = TextAlign.End)
                }
                Divider(color = DarkBorder, thickness = 0.5.dp)
            }
        }
    }
}

@Composable
fun FixturesLayout(
    matches: List<Match>,
    teams: List<Team>,
    onStartScoring: (Int) -> Unit,
    onCreateMatchClick: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        if (matches.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.EventNote,
                        contentDescription = "No Matches",
                        tint = CricbuzzGreen.copy(alpha = 0.5f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("No Scheduled Matches", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color.White)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Schedule tournament matches to start recording scores.", color = DarkTextSecondary, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = onCreateMatchClick,
                        colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        enabled = teams.size >= 2,
                        modifier = Modifier.testTag("schedule_match_button")
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Add")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (teams.size >= 2) "Schedule Match" else "Register Teams First", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 80.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Tournament Schedule",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        IconButton(
                            onClick = onCreateMatchClick,
                            colors = IconButtonDefaults.iconButtonColors(contentColor = CricbuzzGreen),
                            modifier = Modifier.testTag("schedule_add_icon")
                        ) {
                            Icon(imageVector = Icons.Default.AddCircle, contentDescription = "Add Match", modifier = Modifier.size(28.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                items(matches) { match ->
                    FixtureCard(match = match, onStartScoring = onStartScoring)
                }
            }
        }
    }
}

@Composable
fun FixtureCard(
    match: Match,
    onStartScoring: (Int) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, if (match.status == "LIVE") CricbuzzGreen else DarkBorder, RoundedCornerShape(12.dp))
            .testTag("fixture_card_${match.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Date & Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.CalendarToday, contentDescription = "Date", tint = DarkTextSecondary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = match.date, style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                }
                
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            when (match.status) {
                                "LIVE" -> Color.Red
                                "COMPLETED" -> CricbuzzGreen.copy(alpha = 0.15f)
                                else -> DarkBorder
                            }
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = match.status,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = when (match.status) {
                            "LIVE" -> Color.White
                            "COMPLETED" -> CricbuzzGreen
                            else -> DarkTextSecondary
                        }
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Body: Teams and Scores
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Team A info
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = match.teamAName, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(6.dp))
                    if (match.status != "UPCOMING") {
                        Text(
                            text = "${match.inn1Runs}/${match.inn1Wickets}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = CricbuzzGreen
                        )
                        Text(
                            text = "(${match.inn1Overs}.${match.inn1Balls} Ov)",
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextSecondary
                        )
                    } else {
                        Text(text = "Home", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                    }
                }

                // VS Divider
                Text(
                    text = "VS",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = DarkBorder,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                // Team B info
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = match.teamBName, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(6.dp))
                    if (match.status != "UPCOMING") {
                        Text(
                            text = if (match.currentInnings == 2 || match.status == "COMPLETED") "${match.inn2Runs}/${match.inn2Wickets}" else "Yet to Bat",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = if (match.currentInnings == 2 || match.status == "COMPLETED") CricbuzzGreen else DarkTextSecondary
                        )
                        if (match.currentInnings == 2 || match.status == "COMPLETED") {
                            Text(
                                text = "(${match.inn2Overs}.${match.inn2Balls} Ov)",
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextSecondary
                            )
                        }
                    } else {
                        Text(text = "Away", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            // Footer / Bottom Row: Result summary or scoring button
            Divider(color = DarkBorder, thickness = 0.5.dp, modifier = Modifier.padding(bottom = 12.dp))

            if (match.status == "COMPLETED") {
                Column {
                    Text(
                        text = match.resultSummary,
                        fontWeight = FontWeight.Bold,
                        color = CricbuzzGreen,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Stars, contentDescription = "MoM", tint = Color(0xFFFFD13B), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Man of the Match: ${match.manOfTheMatch}",
                            style = MaterialTheme.typography.bodySmall,
                            color = DarkTextSecondary
                        )
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Overs Limit: ${match.overs}", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                    
                    Button(
                        onClick = { onStartScoring(match.id) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (match.status == "LIVE") Color.Red else CricbuzzGreen,
                            contentColor = if (match.status == "LIVE") Color.White else Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("start_scoring_${match.id}")
                    ) {
                        Icon(
                            imageVector = if (match.status == "LIVE") Icons.Default.SportsCricket else Icons.Default.PlayArrow,
                            contentDescription = "Score",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (match.status == "LIVE") "Score Live" else "Start Scoring",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
