package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.SportsBaseball
import androidx.compose.material.icons.filled.SportsCricket
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entities.Player
import com.example.ui.theme.CricbuzzGreen
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.viewmodel.CricketViewModel
import java.util.Locale

@Composable
fun StatsScreen(
    viewModel: CricketViewModel,
    modifier: Modifier = Modifier
) {
    val topRunScorers by viewModel.topRunScorers.collectAsState()
    val topWicketTakers by viewModel.topWicketTakers.collectAsState()
    val teams by viewModel.teams.collectAsState()

    var activeStatsTab by remember { mutableStateOf("BATTING") } // BATTING or BOWLING

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Stats Sub-tab headers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkCard)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("BATTING" to "Top Run Scorers", "BOWLING" to "Top Wicket Takers").forEach { (tabId, tabName) ->
                    val isActive = activeStatsTab == tabId
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isActive) CricbuzzGreen else Color.Transparent)
                            .clickable { activeStatsTab = tabId }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tabName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isActive) Color.Black else Color.White
                        )
                    }
                }
            }

            if (activeStatsTab == "BATTING") {
                // Batting Leaderboard
                if (topRunScorers.isEmpty() || topRunScorers.all { it.runs == 0 }) {
                    EmptyStatsLayout(icon = Icons.Default.SportsCricket, title = "No Batting Stats Yet")
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            // Column Header
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(DarkBorder, RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Text("#", modifier = Modifier.width(24.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary)
                                Text("PLAYER", modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                                Text("TEAM", modifier = Modifier.weight(0.8f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                                Text("B", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White, textAlign = TextAlign.Center)
                                Text("4s/6s", modifier = Modifier.weight(0.5f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White, textAlign = TextAlign.Center)
                                Text("SR", modifier = Modifier.weight(0.4f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White, textAlign = TextAlign.Center)
                                Text("RUNS", modifier = Modifier.weight(0.5f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = CricbuzzGreen, textAlign = TextAlign.End)
                            }
                        }

                        itemsIndexed(topRunScorers) { index, player ->
                            val teamName = teams.find { it.id == player.teamId }?.name ?: "Unknown"
                            val strikeRate = if (player.ballsFaced > 0) (player.runs.toDouble() / player.ballsFaced) * 100 else 0.0
                            val formattedSr = String.format(Locale.US, "%.1f", strikeRate)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(DarkCard)
                                    .border(
                                        width = if (index == 0) 1.dp else 0.dp,
                                        color = if (index == 0) Color(0xFFFF9800) else Color.Transparent, // Golden Bat border for Leader
                                        shape = RoundedCornerShape(0.dp)
                                    )
                                    .padding(horizontal = 12.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Rank
                                Box(
                                    modifier = Modifier
                                        .width(24.dp)
                                        .height(24.dp)
                                        .clip(CircleShape)
                                        .background(if (index == 0) Color(0xFFFF9800) else Color.Transparent),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${index + 1}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = if (index == 0) Color.Black else DarkTextSecondary
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))

                                // Player Info
                                Column(modifier = Modifier.weight(1.2f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = player.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color.White
                                        )
                                        if (index == 0) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = "Leader", tint = Color(0xFFFFD13B), modifier = Modifier.size(14.dp))
                                        }
                                    }
                                }

                                // Team
                                Text(text = teamName, modifier = Modifier.weight(0.8f), fontSize = 12.sp, color = DarkTextSecondary, maxLines = 1)
                                
                                // Balls Faced
                                Text(text = "${player.ballsFaced}", modifier = Modifier.weight(0.3f), fontSize = 12.sp, color = Color.White, textAlign = TextAlign.Center)
                                
                                // Fours / Sixes
                                Text(text = "${player.fours}/${player.sixes}", modifier = Modifier.weight(0.5f), fontSize = 11.sp, color = Color.White, textAlign = TextAlign.Center)
                                
                                // Strike Rate
                                Text(text = formattedSr, modifier = Modifier.weight(0.4f), fontSize = 11.sp, color = DarkTextSecondary, textAlign = TextAlign.Center)
                                
                                // Total Runs
                                Text(text = "${player.runs}", modifier = Modifier.weight(0.5f), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = CricbuzzGreen, textAlign = TextAlign.End)
                            }
                            Divider(color = DarkBorder, thickness = 0.5.dp)
                        }
                    }
                }
            } else {
                // Bowling Leaderboard
                if (topWicketTakers.isEmpty() || topWicketTakers.all { it.wickets == 0 }) {
                    EmptyStatsLayout(icon = Icons.Default.SportsBaseball, title = "No Bowling Stats Yet")
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(DarkBorder, RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Text("#", modifier = Modifier.width(24.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary)
                                Text("PLAYER", modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                                Text("TEAM", modifier = Modifier.weight(0.8f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                                Text("OVERS", modifier = Modifier.weight(0.4f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White, textAlign = TextAlign.Center)
                                Text("RC", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White, textAlign = TextAlign.Center)
                                Text("ECON", modifier = Modifier.weight(0.4f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White, textAlign = TextAlign.Center)
                                Text("WKTS", modifier = Modifier.weight(0.5f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = CricbuzzGreen, textAlign = TextAlign.End)
                            }
                        }

                        itemsIndexed(topWicketTakers) { index, player ->
                            val teamName = teams.find { it.id == player.teamId }?.name ?: "Unknown"
                            
                            // Econ calculation
                            val oversDec = oversToDecimal(player.oversBowled)
                            val econ = if (oversDec > 0.0) player.runsConceded / oversDec else 0.0
                            val formattedEcon = String.format(Locale.US, "%.2f", econ)

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(DarkCard)
                                    .border(
                                        width = if (index == 0) 1.dp else 0.dp,
                                        color = if (index == 0) Color(0xFF9C27B0) else Color.Transparent, // Purple Cap border for Leader
                                        shape = RoundedCornerShape(0.dp)
                                    )
                                    .padding(horizontal = 12.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Rank
                                Box(
                                    modifier = Modifier
                                        .width(24.dp)
                                        .height(24.dp)
                                        .clip(CircleShape)
                                        .background(if (index == 0) Color(0xFF9C27B0) else Color.Transparent),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${index + 1}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = if (index == 0) Color.White else DarkTextSecondary
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))

                                // Player Name
                                Column(modifier = Modifier.weight(1.2f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = player.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color.White
                                        )
                                        if (index == 0) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = "Leader", tint = Color(0xFFFFD13B), modifier = Modifier.size(14.dp))
                                        }
                                    }
                                }

                                // Team
                                Text(text = teamName, modifier = Modifier.weight(0.8f), fontSize = 12.sp, color = DarkTextSecondary, maxLines = 1)
                                
                                // Overs Bowled
                                Text(text = "${player.oversBowled}", modifier = Modifier.weight(0.4f), fontSize = 12.sp, color = Color.White, textAlign = TextAlign.Center)
                                
                                // Runs Conceded
                                Text(text = "${player.runsConceded}", modifier = Modifier.weight(0.3f), fontSize = 12.sp, color = Color.White, textAlign = TextAlign.Center)
                                
                                // Economy
                                Text(text = formattedEcon, modifier = Modifier.weight(0.4f), fontSize = 11.sp, color = DarkTextSecondary, textAlign = TextAlign.Center)
                                
                                // Wickets
                                Text(text = "${player.wickets}", modifier = Modifier.weight(0.5f), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = CricbuzzGreen, textAlign = TextAlign.End)
                            }
                            Divider(color = DarkBorder, thickness = 0.5.dp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyStatsLayout(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = "No stats",
                tint = CricbuzzGreen.copy(alpha = 0.5f),
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Once matches are completed, stats will populate and showcase player rankings across the tournament.", color = DarkTextSecondary, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodySmall)
        }
    }
}

// Helper to convert Double overs format (e.g. 2.3 overs) to raw fractional decimal (2.5 overs) for division
private fun oversToDecimal(overs: Double): Double {
    val completedOvers = overs.toInt()
    val remainingBalls = ((overs - completedOvers) * 10).toInt()
    return completedOvers + (remainingBalls / 6.0)
}
