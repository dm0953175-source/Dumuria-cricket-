package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.entities.*
import com.example.data.repository.CricketRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class CricketViewModel(private val repository: CricketRepository) : ViewModel() {

    // --- Core State flows ---
    val teams: StateFlow<List<Team>> = repository.allTeams.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val pointsTable: StateFlow<List<Team>> = repository.pointsTable
        .map { list ->
            list.sortedWith(
                compareByDescending<Team> { it.points }
                    .thenByDescending { it.netRunRate }
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val matches: StateFlow<List<Match>> = repository.allMatches.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val liveMatch: StateFlow<Match?> = repository.liveMatch.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    val topRunScorers: StateFlow<List<Player>> = repository.topRunScorers.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val topWicketTakers: StateFlow<List<Player>> = repository.topWicketTakers.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // --- Selected / Active Scoring Match States ---
    private val _selectedMatchId = MutableStateFlow<Int?>(null)
    val selectedMatchId: StateFlow<Int?> = _selectedMatchId.asStateFlow()

    val currentMatch: StateFlow<Match?> = _selectedMatchId
        .flatMapLatest { id ->
            if (id == null) flowOf(null) else repository.getMatchById(id)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = null
        )

    val currentMatchPerformances: StateFlow<List<MatchPlayerPerformance>> = _selectedMatchId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getPerformancesForMatch(id)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val currentMatchBalls: StateFlow<List<Ball>> = _selectedMatchId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList()) else repository.getBallsForMatch(id)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Select match for live scoring screen
    fun selectMatch(matchId: Int) {
        _selectedMatchId.value = matchId
    }

    fun deselectMatch() {
        _selectedMatchId.value = null
    }

    // --- Action Handlers ---

    // 1. Teams & Players Management
    fun addTeam(name: String, onComplete: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.insertTeam(name)
            onComplete(id)
        }
    }

    fun addPlayer(teamId: Int, name: String) {
        viewModelScope.launch {
            repository.insertPlayer(teamId, name)
        }
    }

    fun getPlayersForTeam(teamId: Int): Flow<List<Player>> {
        return repository.getPlayersForTeam(teamId)
    }

    // 2. Match Creation
    fun createMatch(
        teamAId: Int,
        teamBId: Int,
        teamAName: String,
        teamBName: String,
        overs: Int,
        date: String
    ) {
        viewModelScope.launch {
            repository.createMatch(teamAId, teamBId, teamAName, teamBName, overs, date)
        }
    }

    // 3. Start Live Scoring & Toss Setup
    fun setupToss(matchId: Int, tossWinnerId: Int, tossDecision: String) {
        viewModelScope.launch {
            val match = repository.getMatchByIdSync(matchId) ?: return@launch
            
            // Determine batting & bowling team based on toss
            val battingTeamId: Int
            val bowlingTeamId: Int
            if (tossWinnerId == match.teamAId) {
                if (tossDecision == "BAT") {
                    battingTeamId = match.teamAId
                    bowlingTeamId = match.teamBId
                } else {
                    battingTeamId = match.teamBId
                    bowlingTeamId = match.teamAId
                }
            } else {
                if (tossDecision == "BAT") {
                    battingTeamId = match.teamBId
                    bowlingTeamId = match.teamAId
                } else {
                    battingTeamId = match.teamAId
                    bowlingTeamId = match.teamBId
                }
            }

            val updatedMatch = match.copy(
                status = "LIVE",
                tossWinnerId = tossWinnerId,
                tossDecision = tossDecision,
                currentInnings = 1,
                battingTeamId = battingTeamId,
                bowlingTeamId = bowlingTeamId,
                resultSummary = "Live Match"
            )
            repository.updateMatch(updatedMatch)
        }
    }

    // Set active Batsmen and Bowler
    fun selectActivePlayers(matchId: Int, strikerId: Int, strikerName: String, nonStrikerId: Int, nonStrikerName: String, bowlerId: Int, bowlerName: String) {
        viewModelScope.launch {
            val match = repository.getMatchByIdSync(matchId) ?: return@launch
            
            // Create performance records so they exist
            repository.getOrInitializePerformance(matchId, strikerId, match.battingTeamId ?: 0, strikerName)
            repository.getOrInitializePerformance(matchId, nonStrikerId, match.battingTeamId ?: 0, nonStrikerName)
            repository.getOrInitializePerformance(matchId, bowlerId, match.bowlingTeamId ?: 0, bowlerName)

            val updated = match.copy(
                strikerId = strikerId,
                nonStrikerId = nonStrikerId,
                bowlerId = bowlerId
            )
            repository.updateMatch(updated)
        }
    }

    // 4. Scoring Events
    fun recordBall(
        matchId: Int,
        runs: Int,
        extras: Int,
        extraType: String?, // "WD", "NB", "LB", "B"
        isWicket: Boolean,
        wicketType: String?,
        dismissedPlayerName: String?,
        nextStrikerId: Int? = null,
        nextNonStrikerId: Int? = null,
        nextBowlerId: Int? = null
    ) {
        viewModelScope.launch {
            val match = repository.getMatchByIdSync(matchId) ?: return@launch
            
            val strikerId = match.strikerId ?: return@launch
            val nonStrikerId = match.nonStrikerId ?: return@launch
            val bowlerId = match.bowlerId ?: return@launch

            val performances = repository.getPerformancesForMatchSync(matchId)
            val strikerName = performances.find { it.playerId == strikerId }?.name ?: "Striker"
            val bowlerName = performances.find { it.playerId == bowlerId }?.name ?: "Bowler"

            // Compute current ball sequence
            val overNo = if (match.currentInnings == 1) match.inn1Overs else match.inn2Overs
            val ballNo = (if (match.currentInnings == 1) match.inn1Balls else match.inn2Balls) + 1

            // Compose over summary text (e.g., "1wd", "4", "W", "nb+1")
            val summaryText = when {
                isWicket -> "W"
                extraType == "WD" -> "${extras}Wd"
                extraType == "NB" -> "${runs}Nb"
                extraType == "LB" -> "${runs}Lb"
                extraType == "B" -> "${runs}B"
                else -> "$runs"
            }

            val ball = Ball(
                matchId = matchId,
                innings = match.currentInnings,
                overNumber = overNo,
                ballNumber = ballNo,
                strikerName = strikerName,
                bowlerName = bowlerName,
                runs = runs,
                extras = extras,
                extraType = extraType,
                isWicket = isWicket,
                wicketType = wicketType,
                dismissedPlayerName = dismissedPlayerName,
                overSummary = summaryText
            )

            // Determine if overs completed
            val legiBall = (extraType != "WD" && extraType != "NB")
            val currentBalls = (if (match.currentInnings == 1) match.inn1Balls else match.inn2Balls)
            val isOversEnd = legiBall && (currentBalls + 1 == 6)

            // Auto rotation of strike if single, triple runs or over completed
            var finalNextStriker = nextStrikerId ?: strikerId
            var finalNextNonStriker = nextNonStrikerId ?: nonStrikerId

            // If runs scored are odd, swap strike
            val runsToConsider = runs + (if (extraType == "LB" || extraType == "B") extras else 0)
            if (runsToConsider % 2 != 0 && !isWicket) {
                val temp = finalNextStriker
                finalNextStriker = finalNextNonStriker
                finalNextNonStriker = temp
            }

            // Swap strike at the end of over
            if (isOversEnd) {
                val temp = finalNextStriker
                finalNextStriker = finalNextNonStriker
                finalNextNonStriker = temp
            }

            repository.scoreBall(
                matchId = matchId,
                ball = ball,
                strikerId = strikerId,
                nonStrikerId = nonStrikerId,
                bowlerId = bowlerId,
                isOversEnd = isOversEnd,
                nextStrikerId = finalNextStriker,
                nextNonStrikerId = finalNextNonStriker,
                nextBowlerId = if (isOversEnd) null else bowlerId // Set bowler null on over complete to force bowler selection!
            )
        }
    }

    // Select Bowler for the new over
    fun changeBowler(matchId: Int, newBowlerId: Int, newBowlerName: String) {
        viewModelScope.launch {
            val match = repository.getMatchByIdSync(matchId) ?: return@launch
            repository.getOrInitializePerformance(matchId, newBowlerId, match.bowlingTeamId ?: 0, newBowlerName)
            repository.updateMatch(match.copy(bowlerId = newBowlerId))
        }
    }

    // Choose next striker after a batsman is dismissed
    fun replaceDismissedStriker(matchId: Int, newBatsmanId: Int, newBatsmanName: String) {
        viewModelScope.launch {
            val match = repository.getMatchByIdSync(matchId) ?: return@launch
            repository.getOrInitializePerformance(matchId, newBatsmanId, match.battingTeamId ?: 0, newBatsmanName)
            repository.updateMatch(match.copy(strikerId = newBatsmanId))
        }
    }

    // Complete Innings 1 and swap teams
    fun startSecondInnings(matchId: Int, strikerId: Int, strikerName: String, nonStrikerId: Int, nonStrikerName: String, bowlerId: Int, bowlerName: String) {
        viewModelScope.launch {
            val match = repository.getMatchByIdSync(matchId) ?: return@launch
            
            // Prepare performances
            repository.getOrInitializePerformance(matchId, strikerId, match.bowlingTeamId ?: 0, strikerName)
            repository.getOrInitializePerformance(matchId, nonStrikerId, match.bowlingTeamId ?: 0, nonStrikerName)
            repository.getOrInitializePerformance(matchId, bowlerId, match.battingTeamId ?: 0, bowlerName)

            repository.completeInnings1(
                matchId = matchId,
                firstBattingTeamId = match.battingTeamId ?: 0,
                firstBowlingTeamId = match.bowlingTeamId ?: 0,
                strikerId = strikerId,
                nonStrikerId = nonStrikerId,
                bowlerId = bowlerId
            )
        }
    }

    // Finish match
    fun finishMatch(matchId: Int, manOfTheMatchName: String?) {
        viewModelScope.launch {
            repository.completeMatch(matchId, manOfTheMatchName)
        }
    }

    // --- Undo Functionality (Scorers' Best Friend) ---
    fun undoLastBall(matchId: Int) {
        viewModelScope.launch {
            val match = repository.getMatchByIdSync(matchId) ?: return@launch
            val balls = repository.getBallsForMatchSync(matchId)
            if (balls.isEmpty()) return@launch

            val lastBall = balls.first() // Latest ball is the first in descending order list
            
            // Delete from DB
            repository.deleteBallById(lastBall.id)

            // Revert Match Scores
            val isLegitimateBall = (lastBall.extraType != "WD" && lastBall.extraType != "NB")
            val totalRuns = lastBall.runs + lastBall.extras
            val totalWicket = if (lastBall.isWicket) 1 else 0
            val isFirstInnings = lastBall.innings == 1

            val revertedMatch = if (isFirstInnings) {
                var newBalls = match.inn1Balls - (if (isLegitimateBall) 1 else 0)
                var newOvers = match.inn1Overs
                if (newBalls < 0) {
                    newBalls = 5
                    newOvers = maxOf(0, newOvers - 1)
                }
                match.copy(
                    inn1Runs = maxOf(0, match.inn1Runs - totalRuns),
                    inn1Wickets = maxOf(0, match.inn1Wickets - totalWicket),
                    inn1Overs = newOvers,
                    inn1Balls = newBalls
                )
            } else {
                var newBalls = match.inn2Balls - (if (isLegitimateBall) 1 else 0)
                var newOvers = match.inn2Overs
                if (newBalls < 0) {
                    newBalls = 5
                    newOvers = maxOf(0, newOvers - 1)
                }
                match.copy(
                    inn2Runs = maxOf(0, match.inn2Runs - totalRuns),
                    inn2Wickets = maxOf(0, match.inn2Wickets - totalWicket),
                    inn2Overs = newOvers,
                    inn2Balls = newBalls
                )
            }
            repository.updateMatch(revertedMatch)

            // Revert striker performance
            val strikerId = match.strikerId
            if (strikerId != null) {
                val strikerPerf = repository.getPerformanceForMatchAndPlayer(matchId, strikerId)
                if (strikerPerf != null) {
                    val ballSubtracted = if (lastBall.extraType == null || lastBall.extraType == "LB" || lastBall.extraType == "B") 1 else 0
                    val updatedStriker = strikerPerf.copy(
                        battingRuns = maxOf(0, strikerPerf.battingRuns - lastBall.runs),
                        battingBalls = maxOf(0, strikerPerf.battingBalls - ballSubtracted),
                        battingFours = maxOf(0, strikerPerf.battingFours - (if (lastBall.runs == 4) 1 else 0)),
                        battingSixes = maxOf(0, strikerPerf.battingSixes - (if (lastBall.runs == 6) 1 else 0))
                    )
                    repository.updatePerformance(updatedStriker)
                }
            }

            // Revert bowler performance
            val bowlerId = match.bowlerId
            if (bowlerId != null) {
                val bowlerPerf = repository.getPerformanceForMatchAndPlayer(matchId, bowlerId)
                if (bowlerPerf != null) {
                    val bowlerRunsConceded = if (lastBall.extraType == "LB" || lastBall.extraType == "B") lastBall.runs else totalRuns
                    val bowlerBallsSubtracted = if (isLegitimateBall) 1 else 0
                    val finalBowlerBalls = maxOf(0, bowlerPerf.bowlingBalls - bowlerBallsSubtracted)
                    val updatedBowler = bowlerPerf.copy(
                        bowlingBalls = finalBowlerBalls,
                        bowlingOvers = finalBowlerBalls / 6,
                        bowlingRunsConceded = maxOf(0, bowlerPerf.bowlingRunsConceded - bowlerRunsConceded),
                        bowlingWickets = maxOf(0, bowlerPerf.bowlingWickets - (if (lastBall.isWicket && lastBall.wicketType != "RUN_OUT") 1 else 0))
                    )
                    repository.updatePerformance(updatedBowler)
                }
            }
        }
    }
}

class CricketViewModelFactory(private val repository: CricketRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CricketViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CricketViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
