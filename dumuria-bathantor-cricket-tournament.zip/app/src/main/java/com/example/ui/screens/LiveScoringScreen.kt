package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entities.Ball
import com.example.data.entities.Match
import com.example.data.entities.MatchPlayerPerformance
import com.example.data.entities.Player
import com.example.ui.theme.CricbuzzGreen
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.viewmodel.CricketViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveScoringScreen(
    viewModel: CricketViewModel,
    matchId: Int,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    
    // Core states
    val matchState by viewModel.currentMatch.collectAsState()
    val performances by viewModel.currentMatchPerformances.collectAsState()
    val balls by viewModel.currentMatchBalls.collectAsState()

    // Observe active match database triggers
    LaunchedEffect(matchId) {
        viewModel.selectMatch(matchId)
    }

    // Modal Control States
    var showWicketDialog by remember { mutableStateOf(false) }
    var showBowlerChangeDialog by remember { mutableStateOf(false) }
    var showBatsmanChangeDialog by remember { mutableStateOf(false) }
    var showFinishMatchDialog by remember { mutableStateOf(false) }

    // Scoring Options Dialog Input
    var wicketTypeSelected by remember { mutableStateOf("BOWLED") }
    var selectedDismissedPlayerName by remember { mutableStateOf("") }
    
    val match = matchState

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Text(
                        text = if (match != null) "${match.teamAName} vs ${match.teamBName}" else "Scoring",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 18.sp
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    if (match != null && match.status != "UPCOMING") {
                        IconButton(
                            onClick = {
                                // Compose live scoring text and link share
                                val scoreText = if (match.currentInnings == 1) {
                                    "${match.teamAName} ${match.inn1Runs}/${match.inn1Wickets} (${match.inn1Overs}.${match.inn1Balls} ov)"
                                } else {
                                    val target = match.inn1Runs + 1
                                    val needRuns = target - match.inn2Runs
                                    val leftBalls = (match.overs * 6) - ((match.inn2Overs * 6) + match.inn2Balls)
                                    "${match.teamBName} ${match.inn2Runs}/${match.inn2Wickets} (${match.inn2Overs}.${match.inn2Balls} ov) - Needs $needRuns from $leftBalls balls. (Target: $target)"
                                }
                                
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_SUBJECT, "Dumuria Bathantor Live Cricket Score!")
                                    putExtra(
                                        Intent.EXTRA_TEXT,
                                        "🏏 *Live Scoring: Dumuria Bathantor Cricket Tournament*\n\n" +
                                        "🔥 *Match Update*:\n$scoreText\n\n" +
                                        "👉 View real-time live ball-by-ball updates and full scorecard here:\n" +
                                        "https://ais-pre-2whmf46vfvvlazykrwfcbt-562373311815.asia-southeast1.run.app/match/$matchId\n\n" +
                                        "Sent via Dumuria Bathantor Scoring App"
                                    )
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Live Score Link"))
                            },
                            modifier = Modifier.testTag("share_score_button")
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = CricbuzzGreen)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkCard)
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (match == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = CricbuzzGreen)
                }
            } else {
                when (match.status) {
                    "UPCOMING" -> {
                        // Display Toss selection screen first
                        TossSetupPanel(match = match, viewModel = viewModel)
                    }
                    "LIVE" -> {
                        // Check if active players (striker/non-striker/bowler) are designated
                        val hasActivePlayers = match.strikerId != null && match.nonStrikerId != null && match.bowlerId != null
                        
                        if (!hasActivePlayers) {
                            // Player Setup interface
                            ActivePlayersSetupPanel(match = match, viewModel = viewModel)
                        } else {
                            // Active Scoring engine dashboard
                            val activeStriker = performances.find { it.playerId == match.strikerId }
                            val activeNonStriker = performances.find { it.playerId == match.nonStrikerId }
                            val activeBowler = performances.find { it.playerId == match.bowlerId }
                            
                            val battingTeamPlayers by viewModel.getPlayersForTeam(match.battingTeamId ?: 0).collectAsState(initial = emptyList())
                            val bowlingTeamPlayers by viewModel.getPlayersForTeam(match.bowlingTeamId ?: 0).collectAsState(initial = emptyList())

                            // Auto trigger dialogs if conditions met
                            // 1. Bowler end of over (6 legitimate balls bowled, bowler is reset to null in repo)
                            if (match.bowlerId == null) {
                                showBowlerChangeDialog = true
                            }

                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                // 1. Scorecard Header Banner
                                MatchScoreHeaderCard(match = match)

                                // 2. Batter & Bowler stats row
                                BatsmenBowlerLiveStatsCard(
                                    striker = activeStriker,
                                    nonStriker = activeNonStriker,
                                    bowler = activeBowler
                                )

                                // 3. Current Over Ball-By-Ball log row
                                CurrentOverTimeline(balls = balls, match = match)

                                Spacer(modifier = Modifier.weight(1f))

                                // 4. Ball Scoring Control Pad
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Score Ball Controls:", fontWeight = FontWeight.SemiBold, fontSize = 12.sp, color = DarkTextSecondary)
                                        
                                        // Quick Undo Button
                                        IconButton(
                                            onClick = { viewModel.undoLastBall(match.id) },
                                            colors = IconButtonDefaults.iconButtonColors(contentColor = Color.Red),
                                            modifier = Modifier.size(36.dp).testTag("undo_button")
                                        ) {
                                            Icon(imageVector = Icons.Default.Undo, contentDescription = "Undo Last", modifier = Modifier.size(20.dp))
                                        }
                                    }

                                    // Primary runs row
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf(0, 1, 2, 3, 4, 6).forEach { run ->
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(DarkCard)
                                                    .border(1.dp, CricbuzzGreen.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                                    .clickable {
                                                        viewModel.recordBall(
                                                            matchId = match.id,
                                                            runs = run,
                                                            extras = 0,
                                                            extraType = null,
                                                            isWicket = false,
                                                            wicketType = null,
                                                            dismissedPlayerName = null
                                                        )
                                                    }
                                                    .padding(vertical = 14.dp)
                                                    .testTag("score_run_$run"),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = "$run",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 18.sp,
                                                    color = CricbuzzGreen
                                                )
                                            }
                                        }
                                    }

                                    // Extras row
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf(
                                            Triple("Wide", "WD", "wd_btn"),
                                            Triple("No Ball", "NB", "nb_btn"),
                                            Triple("Bye", "B", "bye_btn"),
                                            Triple("Leg Bye", "LB", "lb_btn")
                                        ).forEach { (label, type, tag) ->
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(DarkCard)
                                                    .clickable {
                                                        // Score 1 extra
                                                        viewModel.recordBall(
                                                            matchId = match.id,
                                                            runs = 0,
                                                            extras = 1,
                                                            extraType = type,
                                                            isWicket = false,
                                                            wicketType = null,
                                                            dismissedPlayerName = null
                                                        )
                                                    }
                                                    .padding(vertical = 12.dp)
                                                    .testTag(tag),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(label, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                                            }
                                        }
                                    }

                                    // Wicket, Innings/Match Complete Row
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        // WICKET LOGGER BUTTON
                                        Button(
                                            onClick = {
                                                selectedDismissedPlayerName = activeStriker?.name ?: ""
                                                showWicketDialog = true
                                            },
                                            modifier = Modifier
                                                .weight(1.2f)
                                                .height(48.dp)
                                                .testTag("wicket_log_button"),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Cancel, contentDescription = "Wicket")
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("Wicket!", fontWeight = FontWeight.Bold)
                                        }

                                        // COMPLETE INNINGS / END MATCH ACTIONS
                                        val isFirstInningsComplete = match.currentInnings == 1 && (match.inn1Wickets >= 10 || (match.inn1Overs >= match.overs && match.inn1Balls == 0))
                                        val isSecondInningsComplete = match.currentInnings == 2 && (match.inn2Wickets >= 10 || (match.inn2Overs >= match.overs && match.inn2Balls == 0) || (match.inn2Runs > match.inn1Runs))

                                        if (isFirstInningsComplete) {
                                            Button(
                                                onClick = {
                                                    // Trigger active player setup dialog for innings 2
                                                    showBatsmanChangeDialog = true
                                                },
                                                modifier = Modifier
                                                    .weight(1.8f)
                                                    .height(48.dp)
                                                    .testTag("start_inn_2_btn"),
                                                colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("Start 2nd Innings ➔", fontWeight = FontWeight.Bold)
                                            }
                                        } else if (isSecondInningsComplete) {
                                            Button(
                                                onClick = { showFinishMatchDialog = true },
                                                modifier = Modifier
                                                    .weight(1.8f)
                                                    .height(48.dp)
                                                    .testTag("complete_match_action"),
                                                colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("Complete Match 🎉", fontWeight = FontWeight.Bold)
                                            }
                                        } else {
                                            // Regular Live status sharing tip
                                            Box(
                                                modifier = Modifier
                                                    .weight(1.8f)
                                                    .height(48.dp)
                                                    .background(DarkBorder.copy(alpha = 0.3f), RoundedCornerShape(8.dp)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("Tap runs/extras to score", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                                            }
                                        }
                                    }
                                }
                            }

                            // A. Wicket Logging Options Modal
                            if (showWicketDialog) {
                                AlertDialog(
                                    onDismissRequest = { showWicketDialog = false },
                                    title = { Text("Log Dismissal Details", fontWeight = FontWeight.Bold) },
                                    text = {
                                        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                                            Text("Wicket Type:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                listOf("BOWLED", "CAUGHT", "LBW", "RUN_OUT", "STUMPED").forEach { type ->
                                                    val isSelected = wicketTypeSelected == type
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(if (isSelected) Color.Red else DarkBorder)
                                                            .clickable { wicketTypeSelected = type }
                                                            .padding(vertical = 8.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(type.take(4), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                                    }
                                                }
                                            }

                                            Text("Dismissed Player:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                                listOf(activeStriker?.name to true, activeNonStriker?.name to false).forEach { (pName, isStriker) ->
                                                    if (pName != null) {
                                                        val isSelected = selectedDismissedPlayerName == pName
                                                        Box(
                                                            modifier = Modifier
                                                                .weight(1f)
                                                                .clip(RoundedCornerShape(6.dp))
                                                                .background(if (isSelected) Color.Red else DarkBorder)
                                                                .clickable { selectedDismissedPlayerName = pName }
                                                                .padding(vertical = 10.dp),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Text(pName, fontWeight = FontWeight.Bold, color = Color.White)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    confirmButton = {
                                        Button(
                                            onClick = {
                                                viewModel.recordBall(
                                                    matchId = match.id,
                                                    runs = 0,
                                                    extras = 0,
                                                    extraType = null,
                                                    isWicket = true,
                                                    wicketType = wicketTypeSelected,
                                                    dismissedPlayerName = selectedDismissedPlayerName
                                                )
                                                showWicketDialog = false
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.testTag("confirm_wicket_btn")
                                        ) {
                                            Text("Confirm Out", fontWeight = FontWeight.Bold)
                                        }
                                    },
                                    dismissButton = {
                                        TextButton(onClick = { showWicketDialog = false }) {
                                            Text("Cancel", color = MaterialTheme.colorScheme.onBackground)
                                        }
                                    },
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }

                            // B. Over-End Bowler Change Selector Modal
                            if (showBowlerChangeDialog) {
                                AlertDialog(
                                    onDismissRequest = { /* Force selection */ },
                                    title = { Text("Select New Bowler", fontWeight = FontWeight.Bold) },
                                    text = {
                                        Column {
                                            Text("Overs completed. Select a bowler from the bowling team to start the next over.", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                                            Spacer(modifier = Modifier.height(16.dp))
                                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                bowlingTeamPlayers.forEach { pl ->
                                                    val isAlreadyBowler = pl.id == activeBowler?.playerId
                                                    if (!isAlreadyBowler) {
                                                        Row(
                                                            modifier = Modifier
                                                                .fillMaxWidth()
                                                                .clip(RoundedCornerShape(8.dp))
                                                                .background(DarkCard)
                                                                .clickable {
                                                                    viewModel.changeBowler(match.id, pl.id, pl.name)
                                                                    showBowlerChangeDialog = false
                                                                }
                                                                .padding(14.dp),
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Icon(imageVector = Icons.Default.SportsBaseball, contentDescription = "Bowl", tint = CricbuzzGreen)
                                                            Spacer(modifier = Modifier.width(12.dp))
                                                            Text(pl.name, fontWeight = FontWeight.Bold, color = Color.White)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    confirmButton = {},
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }

                            // C. 2nd Innings Openers Selection Dialog
                            if (showBatsmanChangeDialog) {
                                var selectedStrikerId by remember { mutableStateOf<Int?>(null) }
                                var selectedNonStrikerId by remember { mutableStateOf<Int?>(null) }
                                var selectedOpeningBowlerId by remember { mutableStateOf<Int?>(null) }

                                val bowlingRoster = bowlingTeamPlayers // batting team in inn 2
                                val battingRoster = battingTeamPlayers // bowling team in inn 2

                                AlertDialog(
                                    onDismissRequest = {},
                                    title = { Text("Setup 2nd Innings", fontWeight = FontWeight.Bold) },
                                    text = {
                                        Column(
                                            verticalArrangement = Arrangement.spacedBy(10.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("Select Striker (Opening Batter)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                bowlingRoster.take(4).forEach { b ->
                                                    val isSel = selectedStrikerId == b.id
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(if (isSel) CricbuzzGreen else DarkBorder)
                                                            .clickable { selectedStrikerId = b.id }
                                                            .padding(vertical = 8.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(b.name.take(5), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.Black else Color.White)
                                                    }
                                                }
                                            }

                                            Text("Select Non-Striker", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                bowlingRoster.take(4).forEach { b ->
                                                    val isSel = selectedNonStrikerId == b.id
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(if (isSel) CricbuzzGreen else DarkBorder)
                                                            .clickable { selectedNonStrikerId = b.id }
                                                            .padding(vertical = 8.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(b.name.take(5), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.Black else Color.White)
                                                    }
                                                }
                                            }

                                            Text("Select Opening Bowler", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                battingRoster.take(4).forEach { b ->
                                                    val isSel = selectedOpeningBowlerId == b.id
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(if (isSel) CricbuzzGreen else DarkBorder)
                                                            .clickable { selectedOpeningBowlerId = b.id }
                                                            .padding(vertical = 8.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(b.name.take(5), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.Black else Color.White)
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    confirmButton = {
                                        Button(
                                            onClick = {
                                                if (selectedStrikerId != null && selectedNonStrikerId != null && selectedOpeningBowlerId != null && selectedStrikerId != selectedNonStrikerId) {
                                                    val st = bowlingRoster.find { it.id == selectedStrikerId }
                                                    val nst = bowlingRoster.find { it.id == selectedNonStrikerId }
                                                    val bowl = battingRoster.find { it.id == selectedOpeningBowlerId }
                                                    if (st != null && nst != null && bowl != null) {
                                                        viewModel.startSecondInnings(
                                                            matchId = match.id,
                                                            strikerId = st.id,
                                                            strikerName = st.name,
                                                            nonStrikerId = nst.id,
                                                            nonStrikerName = nst.name,
                                                            bowlerId = bowl.id,
                                                            bowlerName = bowl.name
                                                        )
                                                        showBatsmanChangeDialog = false
                                                    }
                                                }
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.testTag("confirm_inn_2_setup")
                                        ) {
                                            Text("Launch Innings ➔", fontWeight = FontWeight.Bold)
                                        }
                                    },
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }

                            // D. Game Over - Declare Man of the Match and Save dialog
                            if (showFinishMatchDialog) {
                                var selectedMoMName by remember { mutableStateOf("") }
                                val allPlayersCombined = battingTeamPlayers + bowlingTeamPlayers

                                AlertDialog(
                                    onDismissRequest = { showFinishMatchDialog = false },
                                    title = { Text("Complete Tournament Match", fontWeight = FontWeight.Bold) },
                                    text = {
                                        Column(
                                            verticalArrangement = Arrangement.spacedBy(12.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("The second innings has concluded. Select the designated Man of the Match to lock in standings.", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text("Select Man of the Match:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                            
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                allPlayersCombined.take(4).forEach { pl ->
                                                    val isSelected = selectedMoMName == pl.name
                                                    Box(
                                                        modifier = Modifier
                                                            .weight(1f)
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(if (isSelected) CricbuzzGreen else DarkBorder)
                                                            .clickable { selectedMoMName = pl.name }
                                                            .padding(vertical = 10.dp),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Text(pl.name.take(6), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (isSelected) Color.Black else Color.White)
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    confirmButton = {
                                        Button(
                                            onClick = {
                                                viewModel.finishMatch(match.id, if (selectedMoMName.isBlank()) "Not Declared" else selectedMoMName)
                                                showFinishMatchDialog = false
                                                onBack() // Back to schedule list after complete!
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.testTag("lock_score_button")
                                        ) {
                                            Text("Lock & Complete Game", fontWeight = FontWeight.Bold)
                                        }
                                    },
                                    dismissButton = {
                                        TextButton(onClick = { showFinishMatchDialog = false }) {
                                            Text("Cancel", color = MaterialTheme.colorScheme.onBackground)
                                        }
                                    },
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            }
                        }
                    }
                    "COMPLETED" -> {
                        // Scoring dashboard view in READ-ONLY mode for completed match
                        CompletedMatchScorecard(match = match, performances = performances, onBack = onBack)
                    }
                }
            }
        }
    }
}

// --- Dynamic Sub-Panels ---

@Composable
fun TossSetupPanel(match: Match, viewModel: CricketViewModel) {
    var selectedWinnerId by remember { mutableStateOf<Int?>(null) }
    var selectedDecision by remember { mutableStateOf<String?>(null) } // BAT or BOWL

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Icon(imageVector = Icons.Default.Casino, contentDescription = "Toss", tint = CricbuzzGreen, modifier = Modifier.size(52.dp))
                
                Text("Match Toss Setup", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge, color = Color.White)
                Text("Specify which team won the toss coin flip and their designated start strategy.", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary, textAlign = TextAlign.Center)
                
                Divider(color = DarkBorder, modifier = Modifier.padding(vertical = 8.dp))

                // Select Toss Winner
                Text("Who won the Toss?", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Color.White)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf(match.teamAId to match.teamAName, match.teamBId to match.teamBName).forEach { (teamId, teamName) ->
                        val isSelected = selectedWinnerId == teamId
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) CricbuzzGreen else DarkBorder)
                                .clickable { selectedWinnerId = teamId }
                                .padding(vertical = 14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(teamName, fontWeight = FontWeight.Bold, color = if (isSelected) Color.Black else Color.White)
                        }
                    }
                }

                // Select Toss Decision
                Text("Toss Decision?", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Color.White)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf("BAT" to "Batting First", "BOWL" to "Bowling First").forEach { (decision, desc) ->
                        val isSelected = selectedDecision == decision
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) CricbuzzGreen else DarkBorder)
                                .clickable { selectedDecision = decision }
                                .padding(vertical = 14.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(desc, fontWeight = FontWeight.Bold, color = if (isSelected) Color.Black else Color.White)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        if (selectedWinnerId != null && selectedDecision != null) {
                            viewModel.setupToss(match.id, selectedWinnerId!!, selectedDecision!!)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("toss_confirm_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    enabled = selectedWinnerId != null && selectedDecision != null
                ) {
                    Text("Confirm & Set Live Score", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun ActivePlayersSetupPanel(match: Match, viewModel: CricketViewModel) {
    val battingTeamPlayers by viewModel.getPlayersForTeam(match.battingTeamId ?: 0).collectAsState(initial = emptyList())
    val bowlingTeamPlayers by viewModel.getPlayersForTeam(match.bowlingTeamId ?: 0).collectAsState(initial = emptyList())

    var strikerId by remember { mutableStateOf<Int?>(null) }
    var nonStrikerId by remember { mutableStateOf<Int?>(null) }
    var bowlerId by remember { mutableStateOf<Int?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Select Active Playing Squads", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, color = Color.White, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Text("Designate opening batters and bowlers to begin the match.", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())

                Divider(color = DarkBorder, modifier = Modifier.padding(vertical = 4.dp))

                // Select Striker
                Text("Striker (On Strike Bat):", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color.White)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    battingTeamPlayers.take(4).forEach { p ->
                        val isSel = strikerId == p.id
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSel) CricbuzzGreen else DarkBorder)
                                .clickable { strikerId = p.id }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(p.name.take(6), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.Black else Color.White)
                        }
                    }
                }

                // Select Non-Striker
                Text("Non-Striker:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color.White)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    battingTeamPlayers.take(4).forEach { p ->
                        val isSel = nonStrikerId == p.id
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSel) CricbuzzGreen else DarkBorder)
                                .clickable { nonStrikerId = p.id }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(p.name.take(6), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.Black else Color.White)
                        }
                    }
                }

                // Select Bowler
                Text("Opening Bowler:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = Color.White)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    bowlingTeamPlayers.take(4).forEach { p ->
                        val isSel = bowlerId == p.id
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSel) CricbuzzGreen else DarkBorder)
                                .clickable { bowlerId = p.id }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(p.name.take(6), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (isSel) Color.Black else Color.White)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        if (strikerId != null && nonStrikerId != null && bowlerId != null && strikerId != nonStrikerId) {
                            val st = battingTeamPlayers.find { it.id == strikerId }
                            val nst = battingTeamPlayers.find { it.id == nonStrikerId }
                            val bowl = bowlingTeamPlayers.find { it.id == bowlerId }
                            if (st != null && nst != null && bowl != null) {
                                viewModel.selectActivePlayers(match.id, st.id, st.name, nst.id, nst.name, bowl.id, bowl.name)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("confirm_openers_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    enabled = strikerId != null && nonStrikerId != null && bowlerId != null && strikerId != nonStrikerId
                ) {
                    Text("Confirm Openers & Begin Match", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun MatchScoreHeaderCard(match: Match) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Innings details label
            Text(
                text = "Innings ${match.currentInnings} - Live scoring",
                style = MaterialTheme.typography.labelSmall,
                color = CricbuzzGreen,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Team A status
                Column(horizontalAlignment = Alignment.Start) {
                    Text(text = match.teamAName, fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color.White)
                    Text(text = "${match.inn1Runs}/${match.inn1Wickets}", fontWeight = FontWeight.Black, fontSize = 28.sp, color = CricbuzzGreen)
                    Text(text = "(${match.inn1Overs}.${match.inn1Balls} ov)", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                }

                // Match status center column
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "VS",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = DarkBorder,
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(CricbuzzGreen.copy(alpha = 0.1f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(text = "Overs: ${match.overs}", fontWeight = FontWeight.Bold, color = CricbuzzGreen, fontSize = 11.sp)
                    }
                }

                // Team B status
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = match.teamBName, fontWeight = FontWeight.Black, fontSize = 16.sp, color = Color.White)
                    if (match.currentInnings == 2) {
                        Text(text = "${match.inn2Runs}/${match.inn2Wickets}", fontWeight = FontWeight.Black, fontSize = 28.sp, color = CricbuzzGreen)
                        Text(text = "(${match.inn2Overs}.${match.inn2Balls} ov)", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                    } else {
                        Text(text = "Yet to bat", fontWeight = FontWeight.Black, fontSize = 18.sp, color = DarkTextSecondary)
                        Text(text = "Innings 2", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = DarkBorder, thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(10.dp))

            // Dynamic live commentary summary (Target / Runs required)
            if (match.currentInnings == 2) {
                val target = match.inn1Runs + 1
                val needRuns = target - match.inn2Runs
                val leftBalls = (match.overs * 6) - ((match.inn2Overs * 6) + match.inn2Balls)

                if (needRuns <= 0) {
                    Text(
                        text = "${match.teamBName} has won the match!",
                        fontWeight = FontWeight.Black,
                        color = CricbuzzGreen,
                        style = MaterialTheme.typography.bodyMedium
                    )
                } else {
                    Text(
                        text = "${match.teamBName} needs $needRuns runs in $leftBalls balls to win (Target: $target)",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD13B),
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Text(
                    text = "${match.teamAName} is setting the target score.",
                    fontWeight = FontWeight.SemiBold,
                    color = DarkTextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun BatsmenBowlerLiveStatsCard(
    striker: MatchPlayerPerformance?,
    nonStriker: MatchPlayerPerformance?,
    bowler: MatchPlayerPerformance?
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Batsmen row
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("BATTER", modifier = Modifier.weight(1.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary)
                Text("R", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary, textAlign = TextAlign.Center)
                Text("B", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary, textAlign = TextAlign.Center)
                Text("4s/6s", modifier = Modifier.weight(0.5f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary, textAlign = TextAlign.Center)
                Text("SR", modifier = Modifier.weight(0.4f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary, textAlign = TextAlign.End)
            }
            Divider(color = DarkBorder, thickness = 0.5.dp)

            // Striker
            if (striker != null) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Row(modifier = Modifier.weight(1.3f), verticalAlignment = Alignment.CenterVertically) {
                        Text(text = striker.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                        Text(text = " *", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = CricbuzzGreen)
                    }
                    Text(text = "${striker.battingRuns}", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CricbuzzGreen, textAlign = TextAlign.Center)
                    Text(text = "${striker.battingBalls}", modifier = Modifier.weight(0.3f), fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center)
                    Text(text = "${striker.battingFours}/${striker.battingSixes}", modifier = Modifier.weight(0.5f), fontSize = 12.sp, color = Color.White, textAlign = TextAlign.Center)
                    
                    val sr = if (striker.battingBalls > 0) (striker.battingRuns.toDouble() / striker.battingBalls) * 100 else 0.0
                    Text(text = String.format(Locale.US, "%.1f", sr), modifier = Modifier.weight(0.4f), fontSize = 12.sp, color = DarkTextSecondary, textAlign = TextAlign.End)
                }
            }

            // Non-Striker
            if (nonStriker != null) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(text = nonStriker.name, modifier = Modifier.weight(1.3f), fontSize = 13.sp, color = DarkTextSecondary)
                    Text(text = "${nonStriker.battingRuns}", modifier = Modifier.weight(0.3f), fontSize = 13.sp, color = DarkTextSecondary, textAlign = TextAlign.Center)
                    Text(text = "${nonStriker.battingBalls}", modifier = Modifier.weight(0.3f), fontSize = 13.sp, color = DarkTextSecondary, textAlign = TextAlign.Center)
                    Text(text = "${nonStriker.battingFours}/${nonStriker.battingSixes}", modifier = Modifier.weight(0.5f), fontSize = 12.sp, color = DarkTextSecondary, textAlign = TextAlign.Center)
                    
                    val sr = if (nonStriker.battingBalls > 0) (nonStriker.battingRuns.toDouble() / nonStriker.battingBalls) * 100 else 0.0
                    Text(text = String.format(Locale.US, "%.1f", sr), modifier = Modifier.weight(0.4f), fontSize = 12.sp, color = DarkTextSecondary, textAlign = TextAlign.End)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Bowler row
            Row(modifier = Modifier.fillMaxWidth()) {
                Text("BOWLER", modifier = Modifier.weight(1.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary)
                Text("O", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary, textAlign = TextAlign.Center)
                Text("M", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary, textAlign = TextAlign.Center)
                Text("R", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary, textAlign = TextAlign.Center)
                Text("W", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary, textAlign = TextAlign.Center)
                Text("ECON", modifier = Modifier.weight(0.5f), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DarkTextSecondary, textAlign = TextAlign.End)
            }
            Divider(color = DarkBorder, thickness = 0.5.dp)

            if (bowler != null) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Row(modifier = Modifier.weight(1.3f), verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.SportsBaseball, contentDescription = "Bowl", tint = CricbuzzGreen.copy(alpha = 0.6f), modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = bowler.name, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                    }
                    val overString = "${bowler.bowlingOvers}.${bowler.bowlingBalls % 6}"
                    Text(text = overString, modifier = Modifier.weight(0.3f), fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center)
                    Text(text = "${bowler.bowlingMaidens}", modifier = Modifier.weight(0.3f), fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center)
                    Text(text = "${bowler.bowlingRunsConceded}", modifier = Modifier.weight(0.3f), fontSize = 13.sp, color = Color.White, textAlign = TextAlign.Center)
                    Text(text = "${bowler.bowlingWickets}", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CricbuzzGreen, textAlign = TextAlign.Center)
                    
                    val oversDec = bowler.bowlingOvers + (bowler.bowlingBalls % 6) / 6.0
                    val econ = if (oversDec > 0.0) bowler.bowlingRunsConceded / oversDec else 0.0
                    Text(text = String.format(Locale.US, "%.2f", econ), modifier = Modifier.weight(0.5f), fontSize = 12.sp, color = DarkTextSecondary, textAlign = TextAlign.End)
                }
            } else {
                Text(text = "Please select bowler for the over.", style = MaterialTheme.typography.bodySmall, color = Color.Red, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
fun CurrentOverTimeline(balls: List<Ball>, match: Match) {
    // Group or filter balls for the current over
    val currentInningsVal = match.currentInnings
    val currentOverNo = if (currentInningsVal == 1) match.inn1Overs else match.inn2Overs
    
    val thisOverBalls = balls.filter { it.innings == currentInningsVal && it.overNumber == currentOverNo }.reversed()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkBorder.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "This Over:",
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp,
            color = DarkTextSecondary,
            modifier = Modifier.padding(end = 8.dp)
        )

        if (thisOverBalls.isEmpty()) {
            Text(text = "Over starting...", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
        } else {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                items(thisOverBalls) { ball ->
                    val isWkt = ball.isWicket
                    val isBoundary = ball.runs == 4 || ball.runs == 6
                    Box(
                        modifier = Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isWkt -> Color.Red
                                    ball.runs == 6 -> Color(0xFFFFD13B) // Gold
                                    ball.runs == 4 -> CricbuzzGreen
                                    else -> DarkBorder
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = ball.overSummary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = if (isWkt || isBoundary) Color.Black else Color.White
                        )
                    }
                }
            }
        }
    }
}

// --- SCORECARD AFTER MATCH COMPLETION (READ ONLY) ---

@Composable
fun CompletedMatchScorecard(
    match: Match,
    performances: List<MatchPlayerPerformance>,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Scorecard top block
        Card(
            modifier = Modifier.fillMaxWidth().border(1.dp, CricbuzzGreen, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "MATCH SCORECARD",
                    style = MaterialTheme.typography.labelSmall,
                    color = CricbuzzGreen,
                    fontWeight = FontWeight.Bold
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(match.teamAName, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                        Text("${match.inn1Runs}/${match.inn1Wickets}", fontWeight = FontWeight.Black, color = CricbuzzGreen, fontSize = 24.sp)
                        Text("(${match.inn1Overs}.${match.inn1Balls} ov)", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                    }

                    Text("VS", fontWeight = FontWeight.Black, color = DarkBorder, fontSize = 14.sp)

                    Column(horizontalAlignment = Alignment.End) {
                        Text(match.teamBName, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                        Text("${match.inn2Runs}/${match.inn2Wickets}", fontWeight = FontWeight.Black, color = CricbuzzGreen, fontSize = 24.sp)
                        Text("(${match.inn2Overs}.${match.inn2Balls} ov)", style = MaterialTheme.typography.bodySmall, color = DarkTextSecondary)
                    }
                }

                Divider(color = DarkBorder, modifier = Modifier.padding(vertical = 4.dp))

                Text(
                    text = match.resultSummary,
                    fontWeight = FontWeight.Black,
                    color = Color(0xFFFFD13B),
                    style = MaterialTheme.typography.bodyMedium
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Stars, contentDescription = "MoM", tint = Color(0xFFFFD13B), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Man of the Match: ${match.manOfTheMatch}",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        // Full performances scorecard list
        Text("Player Performances Scorecard", fontWeight = FontWeight.Bold, color = Color.White, style = MaterialTheme.typography.titleMedium)
        
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkCard),
            shape = RoundedCornerShape(12.dp)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("PLAYER", fontWeight = FontWeight.Bold, color = DarkTextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1.5f))
                        Text("BAT (R/B)", fontWeight = FontWeight.Bold, color = DarkTextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                        Text("BOWL (W/R)", fontWeight = FontWeight.Bold, color = DarkTextSecondary, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                    }
                    Divider(color = DarkBorder, modifier = Modifier.padding(vertical = 4.dp))
                }

                items(performances) { perf ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Name
                        Column(modifier = Modifier.weight(1.5f)) {
                            Text(perf.name, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                            Text(if (perf.isOut) (perf.dismissalInfo ?: "Out") else "not out", fontSize = 11.sp, color = DarkTextSecondary)
                        }

                        // Batting stats
                        Text(
                            text = "${perf.battingRuns} runs (${perf.battingBalls}b)",
                            fontSize = 12.sp,
                            color = if (perf.battingRuns > 0) CricbuzzGreen else Color.White,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center
                        )

                        // Bowling stats
                        val bowlingString = if (perf.bowlingBalls > 0) {
                            "${perf.bowlingWickets} wkts (${perf.bowlingRunsConceded} runs)"
                        } else {
                            "-"
                        }
                        Text(
                            text = bowlingString,
                            fontSize = 12.sp,
                            color = if (perf.bowlingWickets > 0) CricbuzzGreen else Color.White,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.End
                        )
                    }
                    Divider(color = DarkBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                }
            }
        }

        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("close_scorecard_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("Back to Matches", fontWeight = FontWeight.Bold)
        }
    }
}
