package com.example.data.repository

import com.example.data.dao.CricketDao
import com.example.data.entities.*
import kotlinx.coroutines.flow.Flow

class CricketRepository(private val dao: CricketDao) {

    val allTeams: Flow<List<Team>> = dao.getAllTeams()
    val pointsTable: Flow<List<Team>> = dao.getTeamsPointsTable()
    val allMatches: Flow<List<Match>> = dao.getAllMatches()
    val liveMatch: Flow<Match?> = dao.getLiveMatch()
    val topRunScorers: Flow<List<Player>> = dao.getTopRunScorers()
    val topWicketTakers: Flow<List<Player>> = dao.getTopWicketTakers()

    suspend fun insertTeam(name: String): Long {
        return dao.insertTeam(Team(name = name))
    }

    suspend fun insertPlayer(teamId: Int, name: String): Long {
        return dao.insertPlayer(Player(teamId = teamId, name = name))
    }

    fun getPlayersForTeam(teamId: Int): Flow<List<Player>> {
        return dao.getPlayersForTeam(teamId)
    }

    suspend fun getPlayersForTeamSync(teamId: Int): List<Player> {
        return dao.getPlayersForTeamSync(teamId)
    }

    suspend fun createMatch(
        teamAId: Int,
        teamBId: Int,
        teamAName: String,
        teamBName: String,
        overs: Int,
        date: String
    ): Long {
        val match = Match(
            teamAId = teamAId,
            teamBId = teamBId,
            teamAName = teamAName,
            teamBName = teamBName,
            overs = overs,
            status = "UPCOMING",
            date = date,
            resultSummary = "Scheduled"
        )
        return dao.insertMatch(match)
    }

    fun getMatchById(matchId: Int): Flow<Match?> {
        return dao.getMatchById(matchId)
    }

    suspend fun getMatchByIdSync(matchId: Int): Match? {
        return dao.getMatchByIdSync(matchId)
    }

    fun getPerformancesForMatch(matchId: Int): Flow<List<MatchPlayerPerformance>> {
        return dao.getPerformancesForMatch(matchId)
    }

    suspend fun getPerformancesForMatchSync(matchId: Int): List<MatchPlayerPerformance> {
        return dao.getPerformancesForMatchSync(matchId)
    }

    fun getBallsForMatch(matchId: Int): Flow<List<Ball>> {
        return dao.getBallsForMatch(matchId)
    }

    suspend fun getBallsForMatchSync(matchId: Int): List<Ball> {
        return dao.getBallsForMatchSync(matchId)
    }

    suspend fun updateMatch(match: Match) {
        dao.updateMatch(match)
    }

    // Initialize or get performance for a player in a match
    suspend fun getOrInitializePerformance(
        matchId: Int,
        playerId: Int,
        teamId: Int,
        playerName: String
    ): MatchPlayerPerformance {
        val existing = dao.getPerformanceForMatchAndPlayer(matchId, playerId)
        if (existing != null) return existing

        val newPerf = MatchPlayerPerformance(
            matchId = matchId,
            playerId = playerId,
            teamId = teamId,
            name = playerName
        )
        dao.insertPerformance(newPerf)
        return dao.getPerformanceForMatchAndPlayer(matchId, playerId) ?: newPerf
    }

    suspend fun deleteBallById(ballId: Int) {
        dao.deleteBallById(ballId)
    }

    suspend fun updatePerformance(performance: MatchPlayerPerformance) {
        dao.updatePerformance(performance)
    }

    suspend fun getPerformanceForMatchAndPlayer(matchId: Int, playerId: Int): MatchPlayerPerformance? {
        return dao.getPerformanceForMatchAndPlayer(matchId, playerId)
    }

    // Logic to register a scored ball and update matches/performances/players
    suspend fun scoreBall(
        matchId: Int,
        ball: Ball,
        strikerId: Int,
        nonStrikerId: Int,
        bowlerId: Int,
        isOversEnd: Boolean,
        nextStrikerId: Int?,
        nextNonStrikerId: Int?,
        nextBowlerId: Int?
    ) {
        // 1. Insert the ball log
        dao.insertBall(ball)

        // 2. Load Match
        val match = dao.getMatchByIdSync(matchId) ?: return

        // 3. Load striker and bowler performances
        var strikerPerf = getOrInitializePerformance(matchId, strikerId, if (match.currentInnings == 1) match.teamAId else match.teamBId, ball.strikerName)
        var bowlerPerf = getOrInitializePerformance(matchId, bowlerId, if (match.currentInnings == 1) match.teamBId else match.teamAId, ball.bowlerName)

        // Calculate runs & balls for striker
        var runAddedToBatsman = ball.runs
        var ballAddedToBatsman = 0
        if (ball.extraType == null || ball.extraType == "LB" || ball.extraType == "B") {
            ballAddedToBatsman = 1
        }
        
        // Calculate runs & balls for bowler
        var runsConcededByBowler = ball.runs + ball.extras
        if (ball.extraType == "LB" || ball.extraType == "B") {
            // Leg Byes and Byes are not charged to bowler's runs
            runsConcededByBowler = ball.runs
        }
        var ballsBowledByBowler = 0
        if (ball.extraType != "WD" && ball.extraType != "NB") {
            ballsBowledByBowler = 1
        }

        // Update striker performance
        val updatedStriker = strikerPerf.copy(
            battingRuns = strikerPerf.battingRuns + runAddedToBatsman,
            battingBalls = strikerPerf.battingBalls + ballAddedToBatsman,
            battingFours = strikerPerf.battingFours + (if (runAddedToBatsman == 4) 1 else 0),
            battingSixes = strikerPerf.battingSixes + (if (runAddedToBatsman == 6) 1 else 0)
        )
        dao.insertPerformance(updatedStriker)

        // Update bowler performance
        val newBowlerBalls = bowlerPerf.bowlingBalls + ballsBowledByBowler
        val newBowlerOvers = newBowlerBalls / 6
        val newBowlerRemainingBalls = newBowlerBalls % 6
        val updatedBowler = bowlerPerf.copy(
            bowlingBalls = newBowlerBalls,
            bowlingOvers = newBowlerOvers,
            bowlingRunsConceded = bowlerPerf.bowlingRunsConceded + runsConcededByBowler,
            bowlingWickets = bowlerPerf.bowlingWickets + (if (ball.isWicket && ball.wicketType != "RUN_OUT") 1 else 0)
        )
        dao.insertPerformance(updatedBowler)

        // If a wicket fell, update dismissed player
        if (ball.isWicket) {
            val dismissedPlayerName = ball.dismissedPlayerName ?: ball.strikerName
            // Find player ID for dismissed player
            val performances = dao.getPerformancesForMatchSync(matchId)
            val dismissedPerf = performances.find { it.name == dismissedPlayerName }
            if (dismissedPerf != null) {
                dao.insertPerformance(dismissedPerf.copy(
                    isOut = true,
                    dismissalInfo = when (ball.wicketType) {
                        "BOWLED" -> "b ${ball.bowlerName}"
                        "LBW" -> "lbw b ${ball.bowlerName}"
                        "STUMPED" -> "st b ${ball.bowlerName}"
                        "RUN_OUT" -> "run out"
                        else -> "c ${ball.bowlerName}" // default caught
                    }
                ))
            }
        }

        // 4. Update Match Scores
        var currentRuns = ball.runs + ball.extras
        var currentWicket = if (ball.isWicket) 1 else 0

        val nextMatch = if (match.currentInnings == 1) {
            val nextBalls = match.inn1Balls + (if (ball.extraType != "WD" && ball.extraType != "NB") 1 else 0)
            val addedOvers = nextBalls / 6
            val finalBalls = nextBalls % 6
            val finalOvers = match.inn1Overs + addedOvers
            
            match.copy(
                inn1Runs = match.inn1Runs + currentRuns,
                inn1Wickets = match.inn1Wickets + currentWicket,
                inn1Overs = finalOvers,
                inn1Balls = finalBalls,
                strikerId = nextStrikerId ?: match.strikerId,
                nonStrikerId = nextNonStrikerId ?: match.nonStrikerId,
                bowlerId = nextBowlerId ?: match.bowlerId
            )
        } else {
            val nextBalls = match.inn2Balls + (if (ball.extraType != "WD" && ball.extraType != "NB") 1 else 0)
            val addedOvers = nextBalls / 6
            val finalBalls = nextBalls % 6
            val finalOvers = match.inn2Overs + addedOvers
            
            match.copy(
                inn2Runs = match.inn2Runs + currentRuns,
                inn2Wickets = match.inn2Wickets + currentWicket,
                inn2Overs = finalOvers,
                inn2Balls = finalBalls,
                strikerId = nextStrikerId ?: match.strikerId,
                nonStrikerId = nextNonStrikerId ?: match.nonStrikerId,
                bowlerId = nextBowlerId ?: match.bowlerId
            )
        }

        dao.updateMatch(nextMatch)
    }

    // Complete Innings 1 and set up Innings 2
    suspend fun completeInnings1(matchId: Int, firstBattingTeamId: Int, firstBowlingTeamId: Int, strikerId: Int, nonStrikerId: Int, bowlerId: Int) {
        val match = dao.getMatchByIdSync(matchId) ?: return
        dao.updateMatch(match.copy(
            currentInnings = 2,
            battingTeamId = firstBowlingTeamId,
            bowlingTeamId = firstBattingTeamId,
            strikerId = strikerId,
            nonStrikerId = nonStrikerId,
            bowlerId = bowlerId
        ))
    }

    // End match and calculate team and player tournament standings
    suspend fun completeMatch(matchId: Int, manOfTheMatchName: String?) {
        val match = dao.getMatchByIdSync(matchId) ?: return
        if (match.status == "COMPLETED") return

        // 1. Determine winner
        val target = match.inn1Runs + 1
        val winDecision: String
        val winnerId: Int?

        if (match.inn2Runs >= target) {
            // Bowling team chased it (Innings 2 batting team wins)
            winnerId = match.battingTeamId
            val wicketsLeft = 10 - match.inn2Wickets
            val winningTeamName = if (winnerId == match.teamAId) match.teamAName else match.teamBName
            winDecision = "$winningTeamName won by $wicketsLeft wickets"
        } else if (match.inn2Wickets >= 10 || (match.inn2Overs >= match.overs && match.inn2Balls == 0)) {
            if (match.inn2Runs < match.inn1Runs) {
                // Batting team wins (Innings 1 batting team wins)
                winnerId = if (match.battingTeamId == match.teamAId) match.teamBId else match.teamAId
                val runsMargin = match.inn1Runs - match.inn2Runs
                val winningTeamName = if (winnerId == match.teamAId) match.teamAName else match.teamBName
                winDecision = "$winningTeamName won by $runsMargin runs"
            } else {
                // Tie
                winnerId = null
                winDecision = "Match Tied!"
            }
        } else {
            // Default completed state
            winnerId = null
            winDecision = "Match Completed"
        }

        // 2. Update Match
        val completedMatch = match.copy(
            status = "COMPLETED",
            winnerId = winnerId,
            resultSummary = winDecision,
            manOfTheMatch = manOfTheMatchName ?: "Not Declared"
        )
        dao.updateMatch(completedMatch)

        // 3. Update Teams standings for Points Table
        val teamA = dao.getTeamByIdSync(match.teamAId)
        val teamB = dao.getTeamByIdSync(match.teamBId)

        if (teamA != null && teamB != null) {
            val isTeamAWinner = winnerId == teamA.id
            val isTeamBWinner = winnerId == teamB.id
            val isTie = winnerId == null

            // Calculate overs
            val oversFacedA = match.inn1Overs + (match.inn1Balls / 6.0)
            val oversBowledA = match.inn2Overs + (match.inn2Balls / 6.0)

            val oversFacedB = match.inn2Overs + (match.inn2Balls / 6.0)
            val oversBowledB = match.inn1Overs + (match.inn1Balls / 6.0)

            val updatedTeamA = teamA.copy(
                matchesPlayed = teamA.matchesPlayed + 1,
                wins = teamA.wins + (if (isTeamAWinner) 1 else 0),
                losses = teamA.losses + (if (isTeamBWinner) 1 else 0),
                ties = teamA.ties + (if (isTie) 1 else 0),
                points = teamA.points + (if (isTeamAWinner) 2 else if (isTie) 1 else 0),
                runsScored = teamA.runsScored + match.inn1Runs,
                oversFaced = formatOvers(teamA.oversFaced + oversFacedA),
                runsConceded = teamA.runsConceded + match.inn2Runs,
                oversBowled = formatOvers(teamA.oversBowled + oversBowledA)
            )

            val updatedTeamB = teamB.copy(
                matchesPlayed = teamB.matchesPlayed + 1,
                wins = teamB.wins + (if (isTeamBWinner) 1 else 0),
                losses = teamB.losses + (if (isTeamAWinner) 1 else 0),
                ties = teamB.ties + (if (isTie) 1 else 0),
                points = teamB.points + (if (isTeamBWinner) 2 else if (isTie) 1 else 0),
                runsScored = teamB.runsScored + match.inn2Runs,
                oversFaced = formatOvers(teamB.oversFaced + oversFacedB),
                runsConceded = teamB.runsConceded + match.inn1Runs,
                oversBowled = formatOvers(teamB.oversBowled + oversBowledB)
            )

            dao.updateTeam(updatedTeamA)
            dao.updateTeam(updatedTeamB)
        }

        // 4. Update Players aggregated statistics in the database
        val performances = dao.getPerformancesForMatchSync(matchId)
        for (perf in performances) {
            val player = dao.getPlayerByIdSync(perf.playerId)
            if (player != null) {
                val updatedPlayer = player.copy(
                    runs = player.runs + perf.battingRuns,
                    ballsFaced = player.ballsFaced + perf.battingBalls,
                    fours = player.fours + perf.battingFours,
                    sixes = player.sixes + perf.battingSixes,
                    wickets = player.wickets + perf.bowlingWickets,
                    runsConceded = player.runsConceded + perf.bowlingRunsConceded,
                    oversBowled = formatOvers(player.oversBowled + (perf.bowlingOvers + (perf.bowlingBalls / 6.0)))
                )
                dao.updatePlayer(updatedPlayer)
            }
        }
    }

    private fun formatOvers(overs: Double): Double {
        val completedOvers = overs.toInt()
        val remainingBallsDecimal = overs - completedOvers
        var totalBalls = (completedOvers * 6) + Math.round(remainingBallsDecimal * 10).toInt()
        val finalOvers = totalBalls / 6
        val finalBalls = totalBalls % 6
        return finalOvers + (finalBalls / 10.0)
    }
}
