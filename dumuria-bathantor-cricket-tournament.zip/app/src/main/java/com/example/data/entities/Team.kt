package com.example.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "teams")
data class Team(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val matchesPlayed: Int = 0,
    val wins: Int = 0,
    val losses: Int = 0,
    val ties: Int = 0,
    val points: Int = 0,
    val runsScored: Int = 0,
    val oversFaced: Double = 0.0,
    val runsConceded: Int = 0,
    val oversBowled: Double = 0.0
) {
    val netRunRate: Double
        get() {
            if (oversFaced == 0.0 && oversBowled == 0.0) return 0.0
            val batRate = if (oversFaced > 0.0) runsScored / oversToDecimal(oversFaced) else 0.0
            val bowlRate = if (oversBowled > 0.0) runsConceded / oversToDecimal(oversBowled) else 0.0
            return batRate - bowlRate
        }

    companion object {
        fun oversToDecimal(overs: Double): Double {
            val completedOvers = overs.toInt()
            val remainingBalls = ((overs - completedOvers) * 10).toInt()
            return completedOvers + (remainingBalls / 6.0)
        }
    }
}
