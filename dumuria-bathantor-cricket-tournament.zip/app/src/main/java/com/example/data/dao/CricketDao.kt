package com.example.data.dao

import androidx.room.*
import com.example.data.entities.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CricketDao {

    // --- Teams ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTeam(team: Team): Long

    @Update
    suspend fun updateTeam(team: Team)

    @Query("SELECT * FROM teams ORDER BY name ASC")
    fun getAllTeams(): Flow<List<Team>>

    @Query("SELECT * FROM teams ORDER BY points DESC")
    fun getTeamsPointsTable(): Flow<List<Team>>

    @Query("SELECT * FROM teams WHERE id = :teamId LIMIT 1")
    fun getTeamById(teamId: Int): Flow<Team?>

    @Query("SELECT * FROM teams WHERE id = :teamId LIMIT 1")
    suspend fun getTeamByIdSync(teamId: Int): Team?


    // --- Players ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlayer(player: Player): Long

    @Update
    suspend fun updatePlayer(player: Player)

    @Query("SELECT * FROM players WHERE teamId = :teamId ORDER BY name ASC")
    fun getPlayersForTeam(teamId: Int): Flow<List<Player>>

    @Query("SELECT * FROM players WHERE teamId = :teamId ORDER BY name ASC")
    suspend fun getPlayersForTeamSync(teamId: Int): List<Player>

    @Query("SELECT * FROM players ORDER BY runs DESC, name ASC LIMIT 10")
    fun getTopRunScorers(): Flow<List<Player>>

    @Query("SELECT * FROM players ORDER BY wickets DESC, name ASC LIMIT 10")
    fun getTopWicketTakers(): Flow<List<Player>>

    @Query("SELECT * FROM players WHERE id = :playerId LIMIT 1")
    suspend fun getPlayerByIdSync(playerId: Int): Player?


    // --- Matches ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(match: Match): Long

    @Update
    suspend fun updateMatch(match: Match)

    @Query("SELECT * FROM matches ORDER BY id DESC")
    fun getAllMatches(): Flow<List<Match>>

    @Query("SELECT * FROM matches WHERE status = 'LIVE' LIMIT 1")
    fun getLiveMatch(): Flow<Match?>

    @Query("SELECT * FROM matches WHERE id = :matchId LIMIT 1")
    fun getMatchById(matchId: Int): Flow<Match?>

    @Query("SELECT * FROM matches WHERE id = :matchId LIMIT 1")
    suspend fun getMatchByIdSync(matchId: Int): Match?


    // --- Performances ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerformance(performance: MatchPlayerPerformance): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerformances(performances: List<MatchPlayerPerformance>)

    @Update
    suspend fun updatePerformance(performance: MatchPlayerPerformance)

    @Query("SELECT * FROM match_player_performances WHERE matchId = :matchId")
    fun getPerformancesForMatch(matchId: Int): Flow<List<MatchPlayerPerformance>>

    @Query("SELECT * FROM match_player_performances WHERE matchId = :matchId")
    suspend fun getPerformancesForMatchSync(matchId: Int): List<MatchPlayerPerformance>

    @Query("SELECT * FROM match_player_performances WHERE matchId = :matchId AND playerId = :playerId LIMIT 1")
    suspend fun getPerformanceForMatchAndPlayer(matchId: Int, playerId: Int): MatchPlayerPerformance?


    // --- Balls ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBall(ball: Ball): Long

    @Query("DELETE FROM balls WHERE id = :ballId")
    suspend fun deleteBallById(ballId: Int)

    @Query("SELECT * FROM balls WHERE matchId = :matchId ORDER BY id DESC")
    fun getBallsForMatch(matchId: Int): Flow<List<Ball>>

    @Query("SELECT * FROM balls WHERE matchId = :matchId ORDER BY id DESC")
    suspend fun getBallsForMatchSync(matchId: Int): List<Ball>
}
