package com.example.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "matches")
data class Match(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val teamAId: Int,
    val teamBId: Int,
    val teamAName: String,
    val teamBName: String,
    val overs: Int,
    val status: String = "UPCOMING", // "UPCOMING", "LIVE", "COMPLETED"
    val tossWinnerId: Int? = null,
    val tossDecision: String? = null, // "BAT" or "BOWL"
    val currentInnings: Int = 1, // 1 or 2
    val battingTeamId: Int? = null,
    val bowlingTeamId: Int? = null,
    
    // Innings 1 score
    val inn1Runs: Int = 0,
    val inn1Wickets: Int = 0,
    val inn1Overs: Int = 0,
    val inn1Balls: Int = 0,
    
    // Innings 2 score
    val inn2Runs: Int = 0,
    val inn2Wickets: Int = 0,
    val inn2Overs: Int = 0,
    val inn2Balls: Int = 0,
    
    // Live match striker/non-striker/bowler IDs
    val strikerId: Int? = null,
    val nonStrikerId: Int? = null,
    val bowlerId: Int? = null,
    
    // Result
    val winnerId: Int? = null,
    val resultSummary: String = "Upcoming Match",
    val manOfTheMatch: String? = null,
    val date: String = ""
)
