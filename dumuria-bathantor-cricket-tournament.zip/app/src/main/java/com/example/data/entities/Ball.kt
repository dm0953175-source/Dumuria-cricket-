package com.example.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "balls")
data class Ball(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val matchId: Int,
    val innings: Int,
    val overNumber: Int,
    val ballNumber: Int,
    val strikerName: String,
    val bowlerName: String,
    val runs: Int,
    val extras: Int,
    val extraType: String? = null, // "WD", "NB", "LB", "B"
    val isWicket: Boolean = false,
    val wicketType: String? = null, // "BOWLED", "CAUGHT", "RUN_OUT", "LBW", "STUMPED"
    val dismissedPlayerName: String? = null,
    val overSummary: String = "" // "4", "6", "W", "1wd", "nb"
)
