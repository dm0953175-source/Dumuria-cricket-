package com.example.data.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "match_player_performances",
    indices = [Index(value = ["matchId", "playerId"], unique = true)]
)
data class MatchPlayerPerformance(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val matchId: Int,
    val playerId: Int,
    val teamId: Int,
    val name: String,
    val battingRuns: Int = 0,
    val battingBalls: Int = 0,
    val battingFours: Int = 0,
    val battingSixes: Int = 0,
    val isOut: Boolean = false,
    val dismissalInfo: String? = null,
    val bowlingOvers: Int = 0,
    val bowlingBalls: Int = 0,
    val bowlingRunsConceded: Int = 0,
    val bowlingWickets: Int = 0,
    val bowlingMaidens: Int = 0
)
