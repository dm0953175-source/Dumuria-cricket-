package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import com.example.data.db.CricketDatabase
import com.example.data.repository.CricketRepository
import com.example.ui.screens.FixturesScreen
import com.example.ui.screens.LiveScoringScreen
import com.example.ui.screens.StatsScreen
import com.example.ui.screens.TeamsScreen
import com.example.ui.theme.CricbuzzDarkGreen
import com.example.ui.theme.CricbuzzGreen
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.CricketViewModel
import com.example.ui.viewmodel.CricketViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize local database and Repository layers
        val database = CricketDatabase.getDatabase(applicationContext)
        val repository = CricketRepository(database.cricketDao())
        
        // 2. Instantiate Main Cricket State Viewmodel
        val viewModel = ViewModelProvider(
            this,
            CricketViewModelFactory(repository)
        )[CricketViewModel::class.java]

        setContent {
            MyApplicationTheme {
                MainAppShell(viewModel)
            }
        }
    }
}

@Composable
fun MainAppShell(viewModel: CricketViewModel) {
    var activeMatchIdToScore by remember { mutableStateOf<Int?>(null) }
    var currentTab by remember { mutableStateOf("LIVE_MATCH") } // LIVE_MATCH, TEAMS, FIXTURES, STATS

    // If a scorekeeper has selected a match to record/score, take over full screen
    if (activeMatchIdToScore != null) {
        LiveScoringScreen(
            viewModel = viewModel,
            matchId = activeMatchIdToScore!!,
            onBack = { activeMatchIdToScore = null }
        )
    } else {
        // Main App Layout Shell
        Scaffold(
            bottomBar = {
                NavigationBar(
                    containerColor = DarkCard,
                    tonalElevation = 8.dp
                ) {
                    val tabsList = listOf(
                        Triple("LIVE_MATCH", Icons.Default.SportsCricket, "Live"),
                        Triple("TEAMS", Icons.Default.Groups, "Teams"),
                        Triple("FIXTURES", Icons.Default.EventNote, "Matches"),
                        Triple("STATS", Icons.Default.EmojiEvents, "Leaders")
                    )
                    
                    tabsList.forEach { (tabId, icon, label) ->
                        val isSelected = currentTab == tabId
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentTab = tabId },
                            icon = { Icon(imageVector = icon, contentDescription = label) },
                            label = { Text(label, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black,
                                selectedTextColor = CricbuzzGreen,
                                unselectedIconColor = DarkTextSecondary,
                                unselectedTextColor = DarkTextSecondary,
                                indicatorColor = CricbuzzGreen
                            ),
                            modifier = Modifier.testTag("tab_item_$tabId")
                        )
                    }
                }
            },
            modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Top Hero Brand Banner (always displayed on main tabs for high identity)
                TournamentHeaderBanner()

                // Display corresponding active Tab
                Box(modifier = Modifier.weight(1f)) {
                    when (currentTab) {
                        "LIVE_MATCH" -> LiveMatchDashboard(
                            viewModel = viewModel,
                            onStartScoring = { id -> activeMatchIdToScore = id },
                            onNavigateToSchedule = { currentTab = "FIXTURES" }
                        )
                        "TEAMS" -> TeamsScreen(viewModel = viewModel)
                        "FIXTURES" -> FixturesScreen(
                            viewModel = viewModel,
                            onStartScoring = { id -> activeMatchIdToScore = id }
                        )
                        "STATS" -> StatsScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun TournamentHeaderBanner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
    ) {
        // Use high-quality generated stadium art!
        Image(
            painter = painterResource(id = R.drawable.img_cricket_hero),
            contentDescription = "Stadium background",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        // Elegant gradient overlay for premium dark atmosphere
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.4f),
                            Color.Black.copy(alpha = 0.95f)
                        )
                    )
                )
        )

        // Text Banner Contents
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = "Dumuria Bathantor",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = CricbuzzGreen,
                letterSpacing = 1.sp
            )
            Text(
                text = "CRICKET TOURNAMENT",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 0.5.sp
            )
            Text(
                text = "Live ball-by-ball scoring & tournament statistics",
                fontSize = 11.sp,
                color = DarkTextSecondary
            )
        }
    }
}

@Composable
fun LiveMatchDashboard(
    viewModel: CricketViewModel,
    onStartScoring: (Int) -> Unit,
    onNavigateToSchedule: () -> Unit
) {
    val liveMatch by viewModel.liveMatch.collectAsState(initial = null)
    val teams by viewModel.teams.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Live match card
        item {
            Text(
                text = "Active Live Matches",
                fontWeight = FontWeight.Bold,
                color = Color.White,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (liveMatch != null) {
                // If there's an active match, display a highlighted live card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(CricbuzzGreen, CricbuzzDarkGreen)
                            )
                        )
                        .clickable { onStartScoring(liveMatch!!.id) }
                        .testTag("live_dashboard_card"),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Custom Pill Badge matching the design HTML
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50.dp))
                                    .background(Color.Black.copy(alpha = 0.3f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(Color.Red)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "LIVE",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    letterSpacing = 0.5.sp
                                )
                            }
                            Text(
                                text = liveMatch!!.date,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = liveMatch!!.teamAName,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${liveMatch!!.inn1Runs}/${liveMatch!!.inn1Wickets}",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 28.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = "(${liveMatch!!.inn1Overs}.${liveMatch!!.inn1Balls} Ov)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color.White.copy(alpha = 0.8f)
                                )
                            }

                            Text(
                                text = "VS",
                                fontWeight = FontWeight.Black,
                                color = Color.White.copy(alpha = 0.5f),
                                fontSize = 14.sp,
                                modifier = Modifier.padding(horizontal = 12.dp)
                            )

                            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                                Text(
                                    text = liveMatch!!.teamBName,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                if (liveMatch!!.currentInnings == 2) {
                                    Text(
                                        text = "${liveMatch!!.inn2Runs}/${liveMatch!!.inn2Wickets}",
                                        fontWeight = FontWeight.Black,
                                        fontSize = 28.sp,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "(${liveMatch!!.inn2Overs}.${liveMatch!!.inn2Balls} Ov)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color.White.copy(alpha = 0.8f)
                                    )
                                } else {
                                    Text(
                                        text = "Yet to bat",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color.White.copy(alpha = 0.7f)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))
                        Divider(color = Color.White.copy(alpha = 0.2f), thickness = 0.5.dp)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (liveMatch!!.currentInnings == 2) "Chasing target..." else "Setting target...",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                color = Color.White.copy(alpha = 0.8f)
                            )

                            Button(
                                onClick = { onStartScoring(liveMatch!!.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.height(38.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SportsCricket,
                                    contentDescription = "Score",
                                    modifier = Modifier.size(16.dp),
                                    tint = Color.Black
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Resume Scoring",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            } else {
                // If no active live matches, show clean dashboard card
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.OfflineBolt, contentDescription = "Offline", tint = CricbuzzGreen.copy(alpha = 0.5f), modifier = Modifier.size(40.dp))
                        Text("No Match Active", fontWeight = FontWeight.Bold, color = Color.White)
                        Text(
                            text = "There are currently no active live matches being scored. Open the Matches schedule to set up a toss and start a game.",
                            color = DarkTextSecondary,
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Button(
                            onClick = onNavigateToSchedule,
                            colors = ButtonDefaults.buttonColors(containerColor = CricbuzzGreen, contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(40.dp)
                        ) {
                            Icon(imageVector = Icons.Default.EventNote, contentDescription = "Schedule", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Go to Matches Schedule", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Quick Stats Overview / Welcome Card
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.EmojiEvents, contentDescription = "Trophy", tint = Color(0xFFFFD13B), modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Dumuria Bathantor Tournament Board", fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    
                    Text(
                        text = "Track matches, player performance statistics (runs and wickets), and the real-time league standings points table.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextSecondary
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkBorder.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Registered Teams", fontSize = 10.sp, color = DarkTextSecondary)
                            Text("${teams.size}", fontWeight = FontWeight.Black, color = CricbuzzGreen, fontSize = 18.sp)
                        }
                        Divider(color = DarkBorder, modifier = Modifier.width(1.dp).height(24.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Total Players", fontSize = 10.sp, color = DarkTextSecondary)
                            // Rough sum
                            val plCount = teams.size * 11 // Mock/display average
                            Text(if (teams.isEmpty()) "0" else "$plCount+", fontWeight = FontWeight.Black, color = CricbuzzGreen, fontSize = 18.sp)
                        }
                    }
                }
            }
        }
    }
}
